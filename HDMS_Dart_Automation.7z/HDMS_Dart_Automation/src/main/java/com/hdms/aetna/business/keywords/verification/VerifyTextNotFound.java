package com.hdms.aetna.business.keywords.verification;
import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;


public class VerifyTextNotFound implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {

		webDriver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

		TestStepExecutionResultVO result = new TestStepExecutionResultVO();
		String expectedValue = params[1];
		LocatorVO locatorVO=new LocatorVO(params[0]);
		WebElement textBoxObj=null;
		try {
			textBoxObj = AutomationUtil.getElement(webDriver, locatorVO);
			//String actualValue=textBoxObj.getAttribute("value");
			String actualValue=textBoxObj.getText();
			System.out.println(actualValue);
			if(actualValue.equalsIgnoreCase(expectedValue))
			{
				result.setDefectDesc("Text found, whereas expected is it should not found");
			}
			else
			{
				result.setStatus(Constants.PASS);
			}
		} catch (Exception e) {

			if(e.getMessage().contains("waiting for presence of element") || e.getMessage().contains("Element not found"))
			{
				result.setStatus(Constants.PASS);
			}
			else
			{
				result.setDefectDesc(e.getMessage());
				return result;
			}
		}
		finally
		{
			webDriver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		}
		return result;
	}
}
