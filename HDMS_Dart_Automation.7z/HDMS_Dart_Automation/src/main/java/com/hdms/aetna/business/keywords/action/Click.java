package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class Click implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String locator = param[0];

		LocatorVO locatorVO=new LocatorVO(locator);

		WebElement objectToClick=null;
		try {

			objectToClick = AutomationUtil.getElement(webDriver, locatorVO);


			//System.out.println("clicking... "+locator);

			objectToClick.click();
		
			//System.out.println("start of the this is for pagesource identification\n\n\n-------------- Source");
			
			//System.out.println(webDriver.getPageSource());
			
			//System.out.println("END of the this is for pagesource identification\n\n\n-------------- Source");

		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}
		result.setStatus(Constants.PASS);
		return result;
	}

}
