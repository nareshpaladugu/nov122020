package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class DoubleClickKeyword implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		if(params[0].isEmpty())
		{
			testStepExecutionResultVO.setDefectDesc("Object locator not provided");
			return testStepExecutionResultVO;
		}

		try {
			Actions act = new Actions(webDriver);
			act.doubleClick(AutomationUtil.getElement(webDriver, params[0])).build().perform();
		} catch (HDMSException e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
            testStepExecutionResultVO.setStatus(Constants.PASS);

 		    return testStepExecutionResultVO;	
	}

}
