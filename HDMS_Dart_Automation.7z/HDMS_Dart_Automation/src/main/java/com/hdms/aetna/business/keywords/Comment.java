package com.hdms.aetna.business.keywords;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class Comment implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO  testCaseExecutionResult = new TestStepExecutionResultVO();
		
		testCaseExecutionResult.setStatus(2);
		
		return testCaseExecutionResult;
		
	}

}
