package com.hdms.aetna.business.keywords.verification;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;


public class VerifyCalculation implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();
		
		LocatorVO locatorVO1=new LocatorVO(params[0]);
		LocatorVO locatorVO2=new LocatorVO(params[1]);
		LocatorVO locatorVO3=new LocatorVO(params[2]);
		
		if(params[0].isEmpty())
		{
			result.setDefectDesc("Locator not provided !");
			return result;
		}
		WebElement textBoxObj1=null;
		WebElement textBoxObj2=null;
		WebElement textBoxObj3=null;
		try {
			textBoxObj1 = AutomationUtil.getElement(webDriver, locatorVO1);
			textBoxObj2 = AutomationUtil.getElement(webDriver, locatorVO2);
			textBoxObj3 = AutomationUtil.getElement(webDriver, locatorVO3);
			
			String actualValue1=textBoxObj1.getText();
			String actualValue2=textBoxObj2.getText();
			String actualValue3=textBoxObj3.getText();
			int val1=Integer.parseInt(actualValue1);
			int val2=Integer.parseInt(actualValue2);
			int expectedValue=Integer.parseInt(actualValue3);
			
			int actualValue;
			 actualValue=val1+val2;
			System.out.println(actualValue);
			
			System.out.println(expectedValue);
			if(actualValue==expectedValue)
			{
				result.setStatus(1);
			}
			else
			{
				result.setDefectDesc("Addition doesnt match : "+expectedValue+ " Act: "+actualValue);

			}
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}
		return result;
	}

}
