package com.hdms.aetna.business.keywords.verification;

public class Test {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub

		long start = System.currentTimeMillis();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		long stop = System.currentTimeMillis();
		
		
		long millis=stop-start;
		
		long second = (millis / 1000) % 60;
		long minute = (millis / (1000 * 60)) % 60;
		long hour = (millis / (1000 * 60 * 60)) % 24;

		String time = String.format("%02d:%02d:%02d", hour, minute, second);
		
		System.out.println(time);
		
	}

}
