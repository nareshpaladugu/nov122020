package com.hdms.aetna.business.keywords.action;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.LoadProperties;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class WaitForReportsToLoad implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		int maxRetries = 20;

		try
		{

			System.out.println("WaitForReportsToLoad... keyword started !");

			webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			waitForElementDisap(webDriver,By.xpath("//span[text()='Apply']"));

			System.out.println("Apply Button gone !");

			webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

			// initial wait...
			waitForElementDisap(webDriver,By.xpath("//div[contains(text(),'Please wait...')]"));

			System.out.println("Inital progress bar gone .......!");

			Thread.sleep(500);

			System.out.println("Initial Progress bar count ... "+webDriver.findElements(By.xpath("//div[contains(@class,'spinny-progress-bar')]")).size());

			//wait for next progress bars 
			waitForElementDisap(webDriver,By.xpath("//div[contains(@class,'spinny-progress-bar')]"));

			System.out.println("There are no more progress bars ... !");

			waitForElementApp(webDriver, By.xpath("//div[contains(@class,'v-grid-tablewrapper')]//thead"));

			System.out.println("Got at least one table header...");


			int tablecount  = webDriver.findElements(By.xpath("//div[contains(@class,'v-grid-tablewrapper')]")).size();

			System.out.println("No of tables... "+tablecount);

			int tableHeaderCount;
			int reportTitleCount;

			int currentTries = 0;

			long start = System.currentTimeMillis();
			
			do
			{
				
				tablecount  = webDriver.findElements(By.xpath("//div[contains(@class,'v-grid-tablewrapper')]")).size();
				
				reportTitleCount  = webDriver.findElements(By.xpath("//div[contains(@class,'sa-reporttitle')]")).size();

				System.out.println("Waiting for report titles.........got "+reportTitleCount+" Exp : "+tablecount +" "+new Date() + " Itr Ct : "+currentTries);

				Thread.sleep(1000);

				currentTries++;

				if(currentTries==maxRetries)
				{
					break;
				}

			}while(tablecount!=reportTitleCount);


			long time = (System.currentTimeMillis()-start)/1000;
			if(tablecount!=reportTitleCount)
			{
				testStepExecutionResultVO.setDefectDesc("Dashboard/report failed : Expected table count is not loaded after "+maxRetries+ " retries, "+ " in " + time +" seconds");	
				return testStepExecutionResultVO;
			}
			System.out.println("titile vs tabke count check took "+(time)+ "seconds.. ");
			
			currentTries = 0;

			do
			{
				tablecount  = webDriver.findElements(By.xpath("//div[contains(@class,'v-grid-tablewrapper')]")).size();
				
				tableHeaderCount  = webDriver.findElements(By.xpath("//div[contains(@class,'v-grid-tablewrapper')]//thead")).size();

				System.out.println("Waiting for table header.........got "+tableHeaderCount+" Exp : "+tablecount);

				Thread.sleep(1000);

				currentTries++;

				if(currentTries==maxRetries)
				{
					break;
				}
				
			}while(tablecount!=tableHeaderCount);


			System.out.println("Done with report load check !!");

		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		finally
		{
			webDriver.manage().timeouts().implicitlyWait(Integer.parseInt(LoadProperties.OBJECT_LOAD_TIME), TimeUnit.SECONDS);
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}



	private void waitForElementApp(WebDriver webDriver,By by)
	{
		WebDriverWait wait = new WebDriverWait(webDriver, 1200);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	private void waitForElementDisap(WebDriver webDriver,By by)
	{
		WebDriverWait wait = new WebDriverWait(webDriver, 1200);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}

}
