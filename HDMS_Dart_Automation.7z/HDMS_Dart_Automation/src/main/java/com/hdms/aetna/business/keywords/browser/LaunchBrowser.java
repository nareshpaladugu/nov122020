package com.hdms.aetna.business.keywords.browser;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.xmlbeans.impl.tool.Extension.Param;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.utils.LoadProperties;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class LaunchBrowser implements KeywordInterface{

	public static String mainWindowHandle="";
	WebDriver webDriver;

	@SuppressWarnings("deprecation")
	@Override
	public TestStepExecutionResultVO execute(WebDriver wd, String... params) {


		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		DesiredCapabilities capabilities = null;

		if(params[1].equalsIgnoreCase("chrome") || params[1].trim().isEmpty())
		{
			try {
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			} catch (IOException e) {
				e.printStackTrace();
			}

			capabilities = DesiredCapabilities.chrome();

			ChromeOptions options = new ChromeOptions();
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\A125636\\Desktop\\test\\chrome85\\chromedriver.exe");
			ChromeDriverService.Builder builder =  new ChromeDriverService.Builder();
			
			//ChromeDriverService srvc = builder.usingDriverExecutable(new File("C:\\Users\\A125636\\Desktop\\test\\chrome\\chromedriver.exe")).usingPort(9515).build();
			
			//ChromeDriverService srvc = builder.usingDriverExecutable(new File("C:\\Users\\A125636\\Desktop\\test\\chrome\\chromedriver.exe")).usingAnyFreePort().build();
			
			/*try {
		        srvc.start();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		   */
			//options.addArguments("user-data-dir=C:/Users/"+System.getProperty("user.name")+"/AppData/Local/Google/Chrome/D");
			options.addArguments("--start-maximized");
			options.addArguments("test-type");
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			//System.setProperty("webdriver.chrome.driver", "chromedriver.exe");

			if(params[2].isEmpty())
				webDriver = new ChromeDriver(capabilities);
			else
				try {

					updateCapabilties(capabilities, params);
					webDriver=new RemoteWebDriver(new URL(params[2]),capabilities);
				} catch (Exception e) {
					e.printStackTrace();
				}

		}
		else if(params[1].equalsIgnoreCase("edge"))
		{
			try {
				Runtime.getRuntime().exec("taskkill /F /IM msedgedriver.exe");
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.setProperty("webdriver.edge.driver", "C:\\Users\\A125636\\Desktop\\test\\chrome85\\msedgedriver.exe");
			capabilities = DesiredCapabilities.edge();
			webDriver = new EdgeDriver(capabilities);
						
			
			if(params[2].isEmpty())
				webDriver = new EdgeDriver(capabilities);
			else
				try {
              Thread.sleep(500);
					updateCapabilties(capabilities, params);
					webDriver=new RemoteWebDriver(new URL(params[2]),capabilities);
				} catch (Exception e) {
					e.printStackTrace();
				}

		}
		else if(params[1].equalsIgnoreCase("firefox"))
		{
			try {
				Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
			} catch (IOException e) {

			}
			capabilities = DesiredCapabilities.firefox();

			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.download.folderList", 2);
			profile.setPreference("browser.download.manager.showWhenStarting", false);
			profile.setPreference("browser.download.dir", "C:\\Users\\A125636\\Desktop\\test");
			profile.setPreference("browser.helperApps.neverAsk.openFile",
					"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml");
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
					"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml");
			profile.setPreference("browser.helperApps.alwaysAsk.force", false);
			profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
			profile.setPreference("browser.download.manager.focusWhenStarting", false);
			profile.setPreference("browser.download.manager.useWindow", false);
			profile.setPreference("browser.download.manager.showAlertOnComplete", false);
			profile.setPreference("browser.download.manager.closeWhenDone", false);


			System.setProperty("webdriver.gecko.driver", "C:\\Users\\A125636\\Desktop\\test\\geckodriver.exe");


			if(params[2].isEmpty())
				webDriver = new FirefoxDriver(profile);
			else
				try {
					updateCapabilties(capabilities, params);
					webDriver=new RemoteWebDriver(new URL(params[2]),capabilities);
				} catch (Exception e) {
					e.printStackTrace();
				}
		}


		else if(params[1].equalsIgnoreCase("ie"))
		{
			try {

				Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
				Thread.sleep(2000);
				capabilities = null;

				capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability("nativeEvents", false);
				capabilities.setCapability("ignoreZoomSetting", true);			
				capabilities.setCapability("enablePersistentHover", true);
				capabilities.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
				capabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);	
				capabilities.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP, true);
				capabilities.setCapability("ignoreProtectedModeSettings", true);
				capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
				capabilities.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR, true);
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://rep.azdev.healthds.com/futrixdp3/app/extracts?_originating_tab_id=38386&_tab_id=38404#!home/jobs\n");
				//Thread.sleep(500);
				//https://analytics.hdms.com/edartnz/app/nv
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://rep.qat.healthds.com/enlightbeta/app/");
				capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://rep.azprd1web1.healthds.com/edartnz/app/nv?");
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://rep.azqat.healthds.com/edart_nightly/app/nv?");
				//https://rep.azqat.healthds.com/edart_nightly/app/nv?
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://rep.qat.healthds.com/edartnzbeta/app/nv");
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://rep.qat.healthds.com/edartnz/app/nv");
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://analytics.hdms.com/edartnz/app/nv");
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://www.redbus.in/");
				//capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://point.hdms.com/SitePages/Home.aspx");
				capabilities.setCapability("requireWindowFocus", true);	
				System.setProperty("webdriver.ie.driver", "C:\\Users\\A125636\\Desktop\\test\\IEDriverServer.exe");


				if(params[2].isEmpty())
					webDriver=new InternetExplorerDriver(capabilities);
				else
					try {
						updateCapabilties(capabilities, params);
						Thread.sleep(500);
						webDriver=new RemoteWebDriver(new URL(params[2]),capabilities);
					} catch (Exception e) {
						e.printStackTrace();
					}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		else
		{
			testStepExecutionResultVO.setDefectDesc("Unknown browser type");
			return testStepExecutionResultVO;
		}

		if(webDriver!=null)
		{
			System.out.println("object load time...................."+Integer.parseInt(LoadProperties.OBJECT_LOAD_TIME));
			webDriver.manage().timeouts().implicitlyWait(Integer.parseInt(LoadProperties.OBJECT_LOAD_TIME), TimeUnit.SECONDS);
			webDriver.manage().timeouts().pageLoadTimeout(Integer.parseInt(LoadProperties.PAGE_LOAD_TIME), TimeUnit.SECONDS);
			webDriver.manage().deleteAllCookies();
			//webDriver.manage().window().setSize(new Dimension(1600,900));
			webDriver.manage().window().maximize();
			
			/*Set<Cookie> allCookies = webDriver.manage().getCookies();

			for(Cookie cookie : allCookies)
			{
				webDriver.manage().addCookie(cookie);
			}*/


			System.out.println("hit url..");

			try {
				System.out.println("Print the parma0 for get url"+params[0]);
				webDriver.get(params[0]);

			} catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				//	JOptionPane.showMessageDialog(null, "ok continue...");
			}
			mainWindowHandle=webDriver.getWindowHandle();
			System.out.println("title.."+webDriver.getTitle());
			System.out.println("mainWindowHandle.."+mainWindowHandle);
			testStepExecutionResultVO.setStatus(1);
		}
		return testStepExecutionResultVO;
	}


	public void updateCapabilties(DesiredCapabilities capabilities,String[] params)
	{

		String param4_OS=params[3];
		String param5_BrowserVersion=params[4];


		/*		Linux

		Windows 10
		Windows 7
		Windows 8
		Windows 8.1
		Windows Vista
		Windows XP
		iPad
		iPhone
		 */
		if(!param4_OS.isEmpty())
		{
			switch (param4_OS) {
			case "Linux": case "Lnx":  capabilities.setPlatform(Platform.LINUX);  			break;

			case "OS X":  capabilities.setPlatform(Platform.MAC);  			break;

			case "Windows 10": case "Win 10":  case "Win10": case "W10": capabilities.setPlatform(Platform.WIN10);  			break;

			case "Windows 7": case "Win 7":  case "Win7": case "W7": capabilities.setCapability("platform", "Windows 7");  			break;

			case "Windows 8": case "Win 8":  case "Win8": case "W8": capabilities.setPlatform(Platform.WIN8);  			break;

			case "Windows 8.1": case "Win 8.1":  case "Win8.1": case "W8.1": capabilities.setPlatform(Platform.WIN8_1);  			break;

			case "Windows Vista": case "Vista": case "Win Vista":  capabilities.setPlatform(Platform.VISTA);  			break;

			case "Windows XP": case "XP": case "Win XP":  capabilities.setPlatform(Platform.XP);  			break;

			default:
				break;
			}
		}

		if(!param5_BrowserVersion.isEmpty())
		{
			capabilities.setVersion(param5_BrowserVersion);
		}


		System.out.println("capabilities.getPlatform(......)"+capabilities.getPlatform());

	}
	public WebDriver getWebDriverInstance() {

		return this.webDriver;
	}

}
