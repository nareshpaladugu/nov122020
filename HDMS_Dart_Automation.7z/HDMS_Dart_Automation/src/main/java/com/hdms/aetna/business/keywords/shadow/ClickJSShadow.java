package com.hdms.aetna.business.keywords.shadow;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class ClickJSShadow implements KeywordInterface{
	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

	
		//LocatorVO locatorVO=new LocatorVO(locator);

		WebElement objectToClick=null;
		String testBox = params[0];
	

		
		try {
/*
			WebElement root = webDriver.findElement(By.tagName("vaadin-text-field")); 			 
			//Instantiate JavascriptExecutor
			JavascriptExecutor js =(JavascriptExecutor) webDriver;			 
			//Get shadow root block from our root
			WebElement shadowRoot = 
			(WebElement) js.executeScript("return arguments[0].shadowRoot", root);			 
			//Search for any element inside
			shadowRoot.findElement(By.tagName("input")).click();
			shadowRoot.findElement(By.tagName("input")).sendKeys("Lost Mountain Hardware");
			
*/
			JavascriptExecutor js = (JavascriptExecutor) webDriver; 
	      	WebElement clearData1 = (WebElement) js.executeScript("return " + testBox + " ");
	      	clearData1.click();
	
			
	
			
			
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;
		}
	
		

		result.setStatus(Constants.PASS);
		return result;
	}

}
