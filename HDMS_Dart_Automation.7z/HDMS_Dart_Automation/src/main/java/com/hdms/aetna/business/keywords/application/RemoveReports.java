package com.hdms.aetna.business.keywords.application;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class RemoveReports implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... param) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();
		String type = param[0];
		try
		{

			int numberOfDeletedElements  = 0;

			List<WebElement> allDeleteRowDimButtons = null;
			
			if(type.toLowerCase().contains("dashboardgroup")) {
				if(webDriver.findElements(By.xpath("//div[contains(text(),'DashboardGroup')]")).size()>0 || webDriver.findElements(By.xpath("//div[contains(text(),'DashboardGroup')]")) !=null ) {

			allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'DashboardGroup')]"));
				}else {
					System.out.println("nothing to delete");
				}
			}
			else if(type.toLowerCase().contains("reportpersonal")) {
				if(webDriver.findElements(By.xpath("//div[contains(text(),'ReportPeronal')]")).size()>0 || webDriver.findElements(By.xpath("//div[contains(text(),'ReportPeronal')]")) !=null ) {

			allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'ReportPeronal')]"));
				}else {
					System.out.println("nothing to delete");
				}
			}
			else if(type.toLowerCase().contains("reportgroup")) {
				if(webDriver.findElements(By.xpath("//div[contains(text(),'ReportGroup')]")).size()>0 || webDriver.findElements(By.xpath("//div[contains(text(),'ReportGroup')]")) !=null ) {

			allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'ReportGroup')]"));
				}else {
					System.out.println("nothing to delete");
				}
			}else if(type.toLowerCase().contains("dashboardpersonal")) {
				if(webDriver.findElements(By.xpath("//div[contains(text(),'DashboardPeronal')]")).size()>0 || webDriver.findElements(By.xpath("//div[contains(text(),'DashboardPeronal')]")) !=null ) {

			allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'DashboardPeronal')]"));
				}else {
					System.out.println("nothing to delete");
				}
			}
			else {
				allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'DashboardGroup')]"));
			}
			
			numberOfDeletedElements = allDeleteRowDimButtons.size();

			for (int i = 0; i <= numberOfDeletedElements; i++) {
				if(type.toLowerCase().contains("dashboardgroup")) {

				allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'DashboardGroup')]/../..//div[@role='button']"));
				
				if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty() && numberOfDeletedElements>0)
				{
					
					allDeleteRowDimButtons.get(0).click();
					webDriver.findElement(By.xpath("//span[text()='Remove']")).click();
					Thread.sleep(6000);
					webDriver.findElement(By.xpath("//span[text()='Yes']")).click();
					Thread.sleep(6000);
				}
				}else if(type.toLowerCase().contains("dashboardpersonal")) {

					allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'DashboardPeronal')]/../..//div[@role='button']"));
					
					if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty() && numberOfDeletedElements>0)
					{
						
						allDeleteRowDimButtons.get(0).click();
						webDriver.findElement(By.xpath("//span[text()='Remove']")).click();
						Thread.sleep(6000);
						webDriver.findElement(By.xpath("//span[text()='Yes']")).click();
						Thread.sleep(6000);
					}
					}
				else if(type.toLowerCase().contains("reportgroup")) {

					allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'ReportGroup')]/../..//div[@role='button']"));
					
					if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty() && numberOfDeletedElements>0)
					{
						
						allDeleteRowDimButtons.get(0).click();
						webDriver.findElement(By.xpath("//span[text()='Remove']")).click();
						Thread.sleep(6000);
						webDriver.findElement(By.xpath("//span[text()='Yes']")).click();
						Thread.sleep(6000);
					}
					}else if(type.toLowerCase().contains("reportpersonal")) {

						allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'ReportPeronal')]/../..//div[@role='button']"));
						
						if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty() && numberOfDeletedElements>0)
						{
							
							allDeleteRowDimButtons.get(0).click();
							webDriver.findElement(By.xpath("//span[text()='Remove']")).click();
							Thread.sleep(6000);
							webDriver.findElement(By.xpath("//span[text()='Yes']")).click();
							Thread.sleep(6000);
						}
						}else{

						System.out.println("No Saved Dimensions");
						}
			}
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	 
	}

}
