package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class DragAndDrop implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();


		LocatorVO elementToDrag=new LocatorVO(param[0]);
		LocatorVO targetLoca=new LocatorVO(param[1]);


		try {

			Thread.sleep(500);

			WebElement element = AutomationUtil.getElement(webDriver, elementToDrag);

			WebElement target = AutomationUtil.getElement(webDriver, targetLoca);

			(new Actions(webDriver)).dragAndDrop(element, target).perform();

			Thread.sleep(5000);

		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}

		result.setStatus(Constants.PASS);
		return result;
	}

}
