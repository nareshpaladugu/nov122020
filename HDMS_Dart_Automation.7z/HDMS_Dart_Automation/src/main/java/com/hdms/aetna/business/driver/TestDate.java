package com.hdms.aetna.business.driver;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println(new Date());
		
		String pattern = "yyyyMMddHHmmss";
		
		DateFormat dateFormat = new SimpleDateFormat(pattern);
		Date date = new Date();
		
		String randomGenDate = dateFormat.format(date);
		
		System.out.println(randomGenDate); 
		
	}

}
