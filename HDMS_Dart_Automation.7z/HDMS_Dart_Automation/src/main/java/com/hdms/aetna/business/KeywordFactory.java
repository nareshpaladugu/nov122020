package com.hdms.aetna.business;



public interface KeywordFactory {
	
	public KeywordInterface get(String keyword);
	
}
