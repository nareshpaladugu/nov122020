package com.hdms.aetna.business.keywords.shadow;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;
public class EnterTextShadowJS implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

	
		//LocatorVO locatorVO=new LocatorVO(locator);

		WebElement objectToClick=null;
		String testBox = params[0];
		String textValueToEnter = params[1];
		
		try {
			//objectToClick = AutomationUtil.getElement(webDriver, locatorVO);

		//	System.out.println("clicking... by ClickJS..... "+locator);

			JavascriptExecutor js = (JavascriptExecutor) webDriver; 
			//WebElement clearData = (WebElement) js.executeScript("return document.querySelector('vaadin-vertical-layout').shadowRoot.querySelector('vaadin-vertical-layout').shadowRoot.querySelector('vaadin-select').shadowRoot.querySelector('vaadin-select-text-field').querySelector('#vaadin-select-text-field-input-0')");
			//WebElement clearData = (WebElement) js.executeScript("return document.querySelector('body > div.client-selector > vaadin-vertical-layout > vaadin-vertical-layout > vaadin-select').shadowRoot.querySelector('vaadin-select-text-field').shadowRoot.querySelector('#vaadin-select-text-field-input-0')");
			// now you can click on clear data button
	      	//clearData.click();
	      	
			//((JavascriptExecutor) webDriver).executeScript("arguments[0].click();", testBox);
			
	      	//Thread.sleep(5000);
	      	
	      	//WebElement clearData1 = (WebElement) js.executeScript("return document.querySelector('body > div.client-selector > vaadin-vertical-layout > vaadin-vertical-layout > vaadin-combo-box:nth-child(2)').shadowRoot.querySelector('#input').shadowRoot.querySelector('#vaadin-text-field-input-1')");
	      	//WebElement clearData1 = (WebElement) js.executeScript("return document.querySelector('body > div.client-selector > vaadin-vertical-layout > vaadin-vertical-layout > vaadin-combo-box:nth-child(2)').shadowRoot.querySelector('#toggleButton')");
//Original working-	      	  WebElement clearData1 = (WebElement) js.executeScript("return document.querySelector('body > div.client-selector > vaadin-vertical-layout > vaadin-vertical-layout > vaadin-combo-box:nth-child(2)').shadowRoot.querySelector('#input').shadowRoot.querySelector('#vaadin-text-field-input-1 > slot:nth-child(2) > input')");
	      	WebElement clearData1 = (WebElement) js.executeScript("return " + testBox + " ");
	      	//clearData1.click();
	  //    	Thread.sleep(3000);

	      	//WebElement clearData2 = (WebElement) js.executeScript("return document.querySelector('body > div.client-selector > vaadin-vertical-layout > vaadin-vertical-layout > vaadin-combo-box:nth-child(2)').shadowRoot.querySelector('#input').shadowRoot.querySelector('#vaadin-text-field-input-1')");
	      	clearData1.clear();
	      	Thread.sleep(2000);
	      	clearData1.sendKeys(textValueToEnter);
	      	Thread.sleep(2000);
	      	clearData1.sendKeys(Keys.ENTER);
	      	Thread.sleep(2000);
	      	//Thread.sleep(3000);
	//      	WebElement clearData2 = (WebElement) js.executeScript("return document.querySelector('body > div.client-selector > vaadin-vertical-layout > vaadin-button').shadowRoot.querySelector('#button')");
	//      	clearData2.click();
	      	
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;
		}

		result.setStatus(Constants.PASS);
		return result;
	}

}


