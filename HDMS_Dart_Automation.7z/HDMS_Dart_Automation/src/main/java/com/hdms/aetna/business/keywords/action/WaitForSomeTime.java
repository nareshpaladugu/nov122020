package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.HDMSWait;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class WaitForSomeTime  implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO  testCaseExecutionResult = new TestStepExecutionResultVO();

		try {

			HDMSWait myWait=new HDMSWait();
			myWait.waitFor(Long.parseLong(params[0]) * 1000);

		} catch (Exception e) {

			testCaseExecutionResult.setDefectDesc("'"+params[0] + "' is a Invalid wait time ");
			return testCaseExecutionResult;
		}
		
		testCaseExecutionResult.setStatus(1);
		return testCaseExecutionResult;
	}



}
