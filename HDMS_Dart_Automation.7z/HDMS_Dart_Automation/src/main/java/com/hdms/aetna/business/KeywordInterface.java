package com.hdms.aetna.business;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.vos.TestStepExecutionResultVO;

public interface KeywordInterface {

	public abstract TestStepExecutionResultVO execute(WebDriver webDriver,String... params) ;
}
