package com.hdms.aetna.utils;

import java.util.List;

import com.hdms.aetna.vos.BusinessProcessVO;

public class ResultVO {

	private String scriptName;
	
	private String browser;
	
	List<BusinessProcessVO> listOfBusniessProcesses;

	public String getScriptName() {
		return scriptName;
	}

	public void setScriptName(String scriptName) {
		this.scriptName = scriptName;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public List<BusinessProcessVO> getListOfBusniessProcesses() {
		return listOfBusniessProcesses;
	}

	public void setListOfBusniessProcesses(
			List<BusinessProcessVO> listOfBusniessProcesses) {
		this.listOfBusniessProcesses = listOfBusniessProcesses;
	}
	
	
}
