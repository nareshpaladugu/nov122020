package com.hdms.aetna.business.keywords.verification;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class VerifyTextContains implements KeywordInterface {
	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();
		String expectedValue = params[1];
		LocatorVO locatorVO=new LocatorVO(params[0]);
		WebElement textBoxObj=null;
		try {
			textBoxObj = AutomationUtil.getElement(webDriver, locatorVO);
			String actualValue=textBoxObj.getAttribute("value");
			System.out.println(actualValue);

			if (actualValue.toLowerCase().contains(expectedValue.toLowerCase()))
			{
				result.setStatus(1);
			}
			else
			{
				result.setDefectDesc("Text doesnt contain : "+expectedValue+ " Act: "+actualValue);

			}
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}
		return result;
	}

}
