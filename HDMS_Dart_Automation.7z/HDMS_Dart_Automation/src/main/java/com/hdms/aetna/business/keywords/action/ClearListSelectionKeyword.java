package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class ClearListSelectionKeyword implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {
		
		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();
		
		try
		{
			Select oDropDown = new Select(AutomationUtil.getElement(webDriver, params[0]));
			oDropDown.deselectAll();

		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);
		
		return testStepExecutionResultVO;	
	}

}
