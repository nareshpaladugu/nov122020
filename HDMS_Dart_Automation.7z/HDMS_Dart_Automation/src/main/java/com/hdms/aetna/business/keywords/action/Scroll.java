package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class Scroll implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String locator = param[0];

		LocatorVO locatorVO=new LocatorVO(locator);

		WebElement objectToClick=null;
		try {
			objectToClick = AutomationUtil.getElement(webDriver, locatorVO);
				System.out.println("clicking... "+locator);
					//1) first click on the scroll-able pane of your page:-

			        Actions clickAction = new Actions(webDriver);
			        clickAction.moveToElement(objectToClick).click().build().perform();

			//2) then scroll with below code:-

			            Actions scrollAction = new Actions(webDriver);
			            scrollAction.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
			            Thread.currentThread().sleep(5000);
			
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}


		result.setStatus(Constants.PASS);
		return result;
	}

}
