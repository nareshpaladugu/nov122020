package com.hdms.aetna.utils;

public class HDMSException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public HDMSException(String message){
		super(message);
	}
	
	public HDMSException(String message, Throwable cause){
		super(message, cause);
	}
}
