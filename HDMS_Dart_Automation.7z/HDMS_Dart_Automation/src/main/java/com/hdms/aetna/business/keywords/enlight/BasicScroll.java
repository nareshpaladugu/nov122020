package com.hdms.aetna.business.keywords.enlight;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class BasicScroll implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();


		WebElement objectToClick=null;
		try {

			//2) then scroll with below code:-

			            //Actions scrollAction = new Actions(webDriver);
			            //scrollAction.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
			            //Thread.currentThread().sleep(5000);
			            JavascriptExecutor js = (JavascriptExecutor) webDriver;
			            js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}


		result.setStatus(Constants.PASS);
		return result;
	}

}

