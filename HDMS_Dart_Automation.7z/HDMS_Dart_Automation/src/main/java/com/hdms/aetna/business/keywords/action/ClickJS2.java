package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class ClickJS2 implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String locator = param[0];

		LocatorVO locatorVO=new LocatorVO(locator);

		WebElement objectToClick=null;
		try {
			objectToClick = AutomationUtil.getElement(webDriver, locatorVO);
			
			Actions actions = new Actions(webDriver);
			actions.moveToElement(objectToClick).click().build().perform();

			System.out.println("clicking... by ClickJS..... "+locator);


			//((JavascriptExecutor) webDriver).executeScript("arguments[0].scrollIntoView(true);", objectToClick);

			//((JavascriptExecutor) webDriver).executeScript("arguments[0].click();", objectToClick);


		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;
		}

		result.setStatus(Constants.PASS);
		return result;
	}

}
