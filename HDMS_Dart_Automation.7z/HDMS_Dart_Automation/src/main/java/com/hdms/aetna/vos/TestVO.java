package com.hdms.aetna.vos;

import java.util.LinkedList;

public class TestVO {

	private LinkedList<BusinessProcessVO> driverRows;

	public LinkedList<BusinessProcessVO> getDriverRows() {
		return driverRows;
	}

	public void setDriverRows(LinkedList<BusinessProcessVO> driverRows) {
		this.driverRows = driverRows;
	}

}
