package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class EnterTextCalculationChrome implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		
		String valueToenter1 = params[1];
		String valueToenter2 = params[3];
		String valueToenter3 = params[0];
		String testBox = params[2];

		LocatorVO locatorVO1=new LocatorVO(valueToenter1);
		LocatorVO locatorVO2=new LocatorVO(valueToenter2);
		LocatorVO locatorVO=new LocatorVO(valueToenter3);
		WebElement textBoxObj1=null;
		WebElement textBoxObj2=null;
		WebElement textBoxObj3=null;
		if(params[0].isEmpty())
		{
			result.setDefectDesc("Locator not provided !");
			return result;
		}
		try {
			
			textBoxObj1 = AutomationUtil.getElement(webDriver, locatorVO1);
			textBoxObj2 = AutomationUtil.getElement(webDriver, locatorVO2);
			textBoxObj3 = AutomationUtil.getElement(webDriver, locatorVO);
			//String actualValue=textBoxObj.getText();
			String text1=textBoxObj1.getText();
			String text2=textBoxObj2.getText();
			
			StringBuilder sb = new StringBuilder();
			String str = sb.append(text1).append(testBox).append(text2).toString();
			textBoxObj3.clear();
			Thread.sleep(1000);
			System.out.println("appendesstring"+str);

			((JavascriptExecutor) webDriver).executeScript("window.focus();");
			((JavascriptExecutor) webDriver).executeScript(
					"arguments[0].value='';",textBoxObj3);

			textBoxObj3.sendKeys(str);
			
			
			
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}

		

		result.setStatus(Constants.PASS);
		return result;
	}

}
