package com.hdms.aetna.business.keywords.verification;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;


public class VerifyColor implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();
		
		LocatorVO locatorVO=new LocatorVO(params[0]);
		String expectedValue = params[1];
		if(params[0].isEmpty())
		{
			result.setDefectDesc("Locator not provided !");
			return result;
		}
		WebElement textBoxObj=null;
		try {
			textBoxObj = AutomationUtil.getElement(webDriver, locatorVO);
			
			String actualValue=textBoxObj.getCssValue("background-color");
			System.out.println("ActualColor is" +actualValue);
			String hex = Color.fromString(actualValue).asHex();
			System.out.println(hex);
			
			if(actualValue.contains(expectedValue))
			{
				result.setStatus(1);
			}
			else
			{
				result.setDefectDesc("Color is not matching exp : "+expectedValue+ " Act: "+actualValue);

			}
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}
		return result;
	}

}
