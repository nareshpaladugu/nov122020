package com.hdms.aetna.business.keywords.browser;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class SelectWindow implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO result =new TestStepExecutionResultVO();

		int  index = Integer.parseInt(params[0]);

		try {

			if(index==1)
			{
				webDriver.switchTo().window(LaunchBrowser.mainWindowHandle);
			}
			else
			{
				Set<String> set = webDriver.getWindowHandles();

				int changeCount = 0;

				for (Iterator<String> iterator = set.iterator(); iterator.hasNext();) 
				{
					String handle = (String) iterator.next();
					webDriver.switchTo().window(handle);

					System.out.println("Browser Title ...."+webDriver.getTitle());
					changeCount++;

					if(changeCount==index)
						break;
				}
			}
		} catch (Exception ex) {
			result.setDefectDesc(ex.getMessage());
			return result;
		}

		finally {

			try {
				webDriver.manage().window().maximize();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		result.setStatus(1);
		return result;
	}

}
