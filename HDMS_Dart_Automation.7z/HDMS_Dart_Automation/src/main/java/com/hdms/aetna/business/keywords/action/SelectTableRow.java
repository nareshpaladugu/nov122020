package com.hdms.aetna.business.keywords.action;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.CommonAutomationTasks;
import com.hdms.aetna.library.ActionLibrary;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class SelectTableRow implements KeywordInterface
{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {

		TestStepExecutionResultVO  testStepExecutionResultVO = new TestStepExecutionResultVO();

		boolean passFlag = false;

		try {

			List<Integer> indices = CommonAutomationTasks.getColumnNumbers(webDriver,new LocatorVO(params[0]), params[1]);

			WebElement dataTable = AutomationUtil.getElement(webDriver, new LocatorVO(params[0]));

			List<WebElement> allRows = (dataTable.findElements(By.tagName("tbody")).get(0)).findElements(By.tagName("tr"));


			for (WebElement singleRow : allRows) {

				String ActaulValRow = null;

				List<WebElement> allCells = singleRow.findElements(By.tagName("td"));

				for (Integer ind : indices) {

					try {
						if(ActaulValRow==null)
							ActaulValRow = allCells.get(ind).getText().trim();
						else
							ActaulValRow = ActaulValRow+"|"+allCells.get(ind).getText().trim();
					} catch (StaleElementReferenceException e) {

						//skip current row, try next
						break;
					}
				}

				if(ActaulValRow.equals(params[2]))
				{
					passFlag=true;
					ActionLibrary.click(webDriver,allCells.get(0));

					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
					}
					//waitForLoadingStage is present...

					System.out.println("Got row................");
				}
			}


		} catch (Exception e) {

			testStepExecutionResultVO.setDefectDesc("Row not found/visible with Data "+params[2]);
		}

		if(passFlag)
		{
			testStepExecutionResultVO.setStatus(1);
		}
		else
		{
			testStepExecutionResultVO.setDefectDesc("Row not found with Data "+params[2]);
		}
		return testStepExecutionResultVO;

	}
}
