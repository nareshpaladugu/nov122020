package com.hdms.aetna.business.keywords;

import java.io.File;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.format.CellDateFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.HDMSConstants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class ExcelCompare implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		try
		{

			String file1 = params[0];

			String file2 = params[1];

			String file3 = params[2];


			String expVal, actVal;

			Workbook wb1 = WorkbookFactory.create(new File(file1));

			Sheet sheetSource = wb1.getSheetAt(0);


			Workbook wb2 = WorkbookFactory.create(new File(file2));

			Sheet sheet2Dest = wb2.getSheetAt(0);


			int noOfRows = sheetSource.getPhysicalNumberOfRows();

			for (int i = 0; i < noOfRows; i++) 
			{
				Row rowObj  = sheetSource.getRow(i);

				Row rowObj2  = sheet2Dest.getRow(i);

				int noOfCols  = rowObj.getPhysicalNumberOfCells();

				for (int j = 0; j < noOfCols; j++) {

					Cell singleCell  = 	rowObj.getCell(j);

					expVal= getCellValue(singleCell);


					Cell singleCell2  = 	rowObj2.getCell(j);

					actVal= getCellValue(singleCell2);


					if(expVal.equals(actVal))
					{
						System.out.println("passs "+"Row : "+i + "col : "+j+" source val : "+expVal +" act val "+actVal);
					}
					else
					{
						//mismatch

						System.out.println("values are mismatching");

						System.out.println("Row : "+i + "col : "+j+" source val : "+expVal +" act val "+actVal);
					}
				}

			}
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}




	public static String getCellValue(org.apache.poi.ss.usermodel.Cell cell) 
	{

		String value = HDMSConstants.EMPTY_STRING;

		if (cell != null) 
		{
			int cellType = cell.getCellType();

			switch (cellType) 
			{

			case Cell.CELL_TYPE_STRING:

				value = cell.getRichStringCellValue().toString();

				if (value.contains("password")) 
				{
					//no need to show password in test data
				}

				break;

			case Cell.CELL_TYPE_NUMERIC:

				if (HSSFDateUtil.isCellDateFormatted(cell))
				{
					Date date2 = cell.getDateCellValue();
					String dateFmt = cell.getCellStyle().getDataFormatString();
					value = new CellDateFormatter(dateFmt).format(date2);
				}else
				{
					cell.setCellType(HSSFCell.CELL_TYPE_STRING);
					value = cell.getStringCellValue();
				}

				break;

			case Cell.CELL_TYPE_BOOLEAN:

				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				value = cell.getStringCellValue();
				break;

			case Cell.CELL_TYPE_BLANK:

				value = HDMSConstants.EMPTY_STRING;
				break;

			default:

				return value;
			}
		} else 
		{
			return value;
		}

		return value;
	}

	public static String handleStringCase(String cellString) {


		return cellString;
	}


}
