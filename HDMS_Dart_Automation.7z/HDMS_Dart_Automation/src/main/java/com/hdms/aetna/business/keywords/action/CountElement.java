package com.hdms.aetna.business.keywords.action;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class CountElement implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String locator = param[0];
		String expCount = param[1];

		try {

			List<WebElement> eleArray = webDriver.findElements( By.xpath(locator));

			if(eleArray.size()==Integer.parseInt(expCount))
			{
				result.setStatus(Constants.PASS);
				return result;
			}
			else
			{
				result.setDefectDesc("Expected Element Count is "+expCount +" Actually found "+ eleArray.size());
				return result;
			}

		} catch (Exception e) {
			result.setDefectDesc(e.getMessage());
			return result;

		}
	}

}
