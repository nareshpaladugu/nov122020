package com.hdms.aetna.business;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.handlefailure.HandlerFailures;
import com.hdms.aetna.business.keywords.browser.LaunchBrowser;
import com.hdms.aetna.business.testdata.DataSheetReader;
import com.hdms.aetna.business.util.KeywordFactoryImpl;
import com.hdms.aetna.email.EmailUtils;
import com.hdms.aetna.reader.TestReader;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSConstants;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.utils.LoadProperties;
import com.hdms.aetna.utils.ResultUtil;
import com.hdms.aetna.utils.ResultVO;
import com.hdms.aetna.vos.BusinessProcessVO;
import com.hdms.aetna.vos.SingleTestStepVO;
import com.hdms.aetna.vos.TestStepExecutionResultVO;
import com.hdms.aetna.vos.TestVO;

public class Test extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableDriver;

	TestVO testvo;

	DefaultTableModel modelDriverTable=new DefaultTableModel(new String[]{"ScenarioName","ToBeExecuted","Test Data File","Row","StartIteration","EndIteration" + 
	""},0);

	DefaultTableModel modelScenarioTable=new DefaultTableModel(new String[]{"Row Num","Test Step Id","ToBeExecuted?","Keyword","Worksheet","Row","Param1",
			"Param2","Param3","Param4","Param5","Param6","Param7","Param8","Step Description","Action On Fail","AOFParam","Result"},0);


	String ScriptFile;
	private JTable tableScenario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test frame = new Test();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Test() {


		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		setTitle("Testing Tool Naresh");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1439, 932);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(12, 525, 1397, 323);
		contentPane.add(tabbedPane_1);


		JPanel driverP= new JPanel();
		driverP.setLayout(null);
		tabbedPane_1.addTab("Driver", driverP);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 1368, 267);
		driverP.add(scrollPane);


		tableDriver = new JTable(modelDriverTable);
		tableDriver.setFont(new Font("Calibri", Font.PLAIN, 17));
		scrollPane.setViewportView(tableDriver);
		tableDriver.setRowHeight(25);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 13, 1397, 498);
		contentPane.add(scrollPane_1);

		tableScenario = new JTable(modelScenarioTable);


		tableScenario.setBounds(592, 169, 1, 1);
		scrollPane_1.setViewportView(tableScenario);


		tableScenario.setFont(new Font("Calibri", Font.PLAIN, 17));
		tableScenario.setRowHeight(25);

		tableScenario.setDefaultRenderer(String.class, new CustomTableRenderer());


		JMenuBar menuBar = new JMenuBar();

		//Build the first menu.
		JMenu menu = new JMenu("File");
		menu.setMnemonic(KeyEvent.VK_F);

		menuBar.add(menu);


		JMenuItem menuItem = new JMenuItem("Load Script",
				KeyEvent.VK_L);
		menu.add(menuItem);

		menuBar.add(menu);


		JMenuItem menuItem2 = new JMenuItem("Run Script",
				KeyEvent.VK_R);
		menu.add(menuItem2);

		menuBar.add(menu);

		menuItem2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

			
				//option 1
				/*
				T t=new T();
				t.start();*/
				
				//option 2
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {

							T t=new T();
							t.start();
							
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

				System.out.println("Here");
			}
		});

		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				File file=null;

				final JFileChooser fc = new JFileChooser("C:\\Users\\npaladug\\Desktop\\file\\");

				int returnVal = fc.showOpenDialog(Test.this);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					file = fc.getSelectedFile();
				} else {
				}

				System.out.println("file.getAbsoluteFile().getAbsolutePath(),, "+file.getAbsoluteFile().getAbsolutePath());

				ScriptFile = file.getAbsoluteFile().getAbsolutePath();
				try {
					testvo= TestReader.readTest(file.getAbsoluteFile().getAbsolutePath());

					LinkedList<BusinessProcessVO> alldriverRows= testvo.getDriverRows();

					for (BusinessProcessVO businessProcessVO : alldriverRows) {


						java.util.Vector<String> v=  new java.util.Vector<>();

						v.add(businessProcessVO.getName());
						v.addElement(businessProcessVO.getToBeExecuted());

						modelDriverTable.addRow(v);
					}

				} catch (HDMSException e) {

					e.printStackTrace();
				}
			}
		});

		setJMenuBar(menuBar);
	}

	class T extends Thread
	{
		public void run()
		{


			runTest(testvo,ScriptFile);
		}
	}
	public void runTest(TestVO testvo,String sTestFileName)
	{
		System.out.println("Executing test : "+sTestFileName);

		AutomationUtil.checkTempFolder();

		ResultVO resultvo=new ResultVO();

		List<BusinessProcessVO> listOfBusniessProcesses=new LinkedList<BusinessProcessVO>();

		resultvo.setScriptName(sTestFileName);

		int totalFaliedTests = 0;
		int totalPassedTests = 0;

		WebDriver webDriver=null;

		try {

			LinkedList<BusinessProcessVO> driverRows = testvo.getDriverRows();

			TestStepExecutionResultVO testStepExecutionResultVO= null;

			Map<String, Map<String, Map<String, String>>>dataMap = new HashMap<String, Map<String,Map<String,String>>>();

			Map<String, String> rowNumberConfigurationMap = new HashMap<String,String>();

			boolean exitFlag = false;

			boolean stopFlag = false;

			int id=0;

			for (BusinessProcessVO businessProcess : driverRows) 
			{

				tableDriver.setRowSelectionInterval(id, id);
				id++;

				if(!businessProcess.getToBeExecuted().equalsIgnoreCase("X") && !businessProcess.getToBeExecuted().equalsIgnoreCase("N"))
				{
					businessProcess.setExecuted(true);

					if(!businessProcess.getTestDataFile().isEmpty())
					{
						try {
							dataMap= DataSheetReader.readDataSheets(businessProcess.getTestDataFile());

							Set<String> sheets = dataMap.keySet();

							for (String sheet : sheets) {

								if(businessProcess.getRowNumber().isEmpty())
								{
									//default row number is 1
									rowNumberConfigurationMap.put(sheet, "1");
								}
								else
								{
									rowNumberConfigurationMap.put(sheet, businessProcess.getRowNumber());
								}
							}

						} catch (HDMSException e) {

							businessProcess.setMessages(e.getMessage());
						}
					}

					LinkedList<TestStepExecutionResultVO> listOfExecutionsSteps=new LinkedList<TestStepExecutionResultVO>();

					Integer passedSoFar = 0;
					Integer failedSoFar = 0;
					Integer skippedSoFar = 0;

					businessProcess.setPassedTests(0);
					businessProcess.setFailedTest(0);
					businessProcess.setSkippedTests(0);

					businessProcess.setStartCalendar(Calendar.getInstance());

					LinkedList<SingleTestStepVO> testSteps =	businessProcess.getTestSteps();


					//TODO

					/*
					DefaultTableModel modelScenarioTable=new DefaultTableModel(new String[]{"Row Num","Test Step Id","ToBeExecuted?","Keyword","Worksheet","Row","Param1",
							"Param2","Param3","Param4","Param5","Param6","Param7","Param8","Step Description","Action On Fail","AOFParam"},0);*/



					int rc = modelScenarioTable.getRowCount();
					for (int i = rc-1; i >= 0; i--) {
						modelScenarioTable.removeRow(i);
					}

					for (SingleTestStepVO singleStep : testSteps) {

						java.util.Vector<String> v=  new java.util.Vector<>();

						v.add(singleStep.getRow());

						v.add(singleStep.getTeststep());

						v.add(singleStep.getToBeExecuted());

						v.add(singleStep.getAction());

						v.add("");
						v.add("");

						v.add(singleStep.getParam1());


						v.add(singleStep.getParam2());

						v.add(singleStep.getParam3());

						v.add(singleStep.getParam4());


						modelScenarioTable.addRow(v);

					}

					System.out.println(modelScenarioTable.getRowCount());

					int startIt = businessProcess.getStartIt();
					int stopIt = businessProcess.getStopIt();

					if(startIt==-1)
					{
						startIt=1;
					}
					startIt--;

					if(stopIt==-1)
					{
						stopIt=businessProcess.getTestSteps().size();
					}

					stopIt--;


					exitFlag = false;

					int rh=0;
					for (int iCurrentTestStepNumber = startIt; iCurrentTestStepNumber <=stopIt; iCurrentTestStepNumber++) {


						tableScenario.setRowSelectionInterval(rh,rh);
						rh++;
						SingleTestStepVO singleTestStepVO = testSteps.get(iCurrentTestStepNumber);

						if(!singleTestStepVO.getToBeExecuted().equalsIgnoreCase("X"))
						{

							Calendar testStartCal= Calendar.getInstance();

							if(singleTestStepVO.getAction().isEmpty())
							{
								continue;
							}

							if(singleTestStepVO.getAction().equalsIgnoreCase("LaunchBrowser"))
							{
								LaunchBrowser launchBrowser = new LaunchBrowser();

								try {
									testStepExecutionResultVO = launchBrowser.execute(null, singleTestStepVO.getParamsList(dataMap, rowNumberConfigurationMap,null));
								} catch (HDMSException e) {

									testStepExecutionResultVO.setDefectDesc(e.getMessage());
								}

								resultvo.setBrowser(singleTestStepVO.getParam2());

								webDriver = launchBrowser.getWebDriverInstance();
							}
							else
							{
								KeywordInterface keyword = KeywordFactoryImpl.getInstance().get(singleTestStepVO.getAction());

								if(keyword==null)
								{
									testStepExecutionResultVO = new TestStepExecutionResultVO();
									testStepExecutionResultVO.setDefectDesc("Unknown Keyword"+singleTestStepVO.getAction());
									System.out.println("Unknown Keyword........");
								}
								else
								{
									try {
										testStepExecutionResultVO = keyword.execute(webDriver, singleTestStepVO.getParamsList(dataMap, rowNumberConfigurationMap,null));
									} catch (HDMSException e) {

										testStepExecutionResultVO.setDefectDesc(e.getMessage());
									}
								}

							}


							int rowSel =tableScenario.getSelectedRow();
							modelScenarioTable.setValueAt( testStepExecutionResultVO.getStrStatus(), rowSel, 17);

							switch (testStepExecutionResultVO.getStatus()) 
							{
							case HDMSConstants.PASS:

								passedSoFar++;
								businessProcess.setPassedTests(passedSoFar);
								totalPassedTests++;

								break;

							case HDMSConstants.FAIL:

								failedSoFar++;
								businessProcess.setFailedTest(failedSoFar);
								totalFaliedTests++;

								if(LoadProperties.CaptureBitmapOnFailure)
								{
									HandlerFailures.captureBitmapHandler(webDriver, sTestFileName, businessProcess,
											singleTestStepVO, testStepExecutionResultVO);
								}

								String sActionOnFail  = singleTestStepVO.getActionOnFail();

								if(sActionOnFail.equalsIgnoreCase(HDMSConstants.ACTION_ON_FAIL_EXIT))
								{
									exitFlag = true;
								}
								else if(sActionOnFail.equalsIgnoreCase(HDMSConstants.ACTION_ON_FAIL_STOP))
								{
									stopFlag = true;
								}
								else if(sActionOnFail.equalsIgnoreCase(HDMSConstants.ACTION_ON_FAIL_JUMP))
								{
									String sActionOnFailRow = singleTestStepVO.getActionOnFailParam();

									if(sActionOnFailRow.isEmpty())
									{
										testStepExecutionResultVO.setStatus(0);
										testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc()+" Action On Fail - Jump row not specified");
									}
									else
									{
										try {
											int jumpRow = Integer.parseInt(sActionOnFailRow);

											if(jumpRow>stopIt)
											{
												testStepExecutionResultVO.setStatus(0);
												testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc()
														+" Action On Fail - Invalid Jump row specified :"+sActionOnFailRow+ ", It should be less than stop iteration");
											}
											else
											{
												iCurrentTestStepNumber=jumpRow-2;
											}

										} catch (NumberFormatException e) {


											testStepExecutionResultVO.setStatus(0);
											testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc()
													+" Action On Fail - Invalid Jump row specified :"+sActionOnFailRow);
										}


									}

								}

								break;

							case HDMSConstants.SKIPPED:

								skippedSoFar++;
								businessProcess.setSkippedTests(skippedSoFar);
								//totalSkippedTest++;
								break;
							}

							if(testStepExecutionResultVO.getTestData().isEmpty())
								testStepExecutionResultVO.setTestData(singleTestStepVO.getParamForTestData());

							testStepExecutionResultVO.setTestCaseID(singleTestStepVO.getTeststep());
							testStepExecutionResultVO.setExecutionTimeStr(AutomationUtil.getExecutionTimingString(Calendar.getInstance()));
							testStepExecutionResultVO.setStepDescription(singleTestStepVO.getStepDescription());

							testStepExecutionResultVO.setStartCalendar(testStartCal);
							testStepExecutionResultVO.setStopCalendar(Calendar.getInstance());

							listOfExecutionsSteps.add(testStepExecutionResultVO);

							if(exitFlag)
							{
								break;
							}


							if(stopFlag)
							{
								break;
							}
						}	
					}

					businessProcess.setStopCalendar(Calendar.getInstance());
					businessProcess.setTestCaseExecutionList(listOfExecutionsSteps);

					listOfBusniessProcesses.add(businessProcess);	

					if(stopFlag)
					{
						break;
					}
				}
			}

			resultvo.setListOfBusniessProcesses(listOfBusniessProcesses);

			String sTestName = AutomationUtil.shortenTestName(sTestFileName);

			String sResultFileName ="./Results/"+sTestName+"_"+ResultUtil.getTimeStamp()+".xls";

			ResultUtil.generateExcelResult(resultvo,sResultFileName);

			if(LoadProperties.CaptureBitmapOnFailure && totalFaliedTests!=0)
			{
				HandlerFailures.generatFailureReport(sTestName+"_"+ResultUtil.getTimeStamp());
			}

			if(LoadProperties.EMAIL_FLAG)
			{
				EmailUtils.sendAutoEmail(sTestName, sResultFileName, totalPassedTests, totalFaliedTests, ResultUtil.calculateTotalTime(listOfBusniessProcesses));
			}

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		finally
		{
			if(webDriver!=null)
			{
				try {
					//webDriver.quit();
				} catch (Exception e) {
				}
			}
		}

	}
}
