package com.hdms.aetna.business.keywords.verification;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;


public class VerifyTextValueJS implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();
		String expectedValue = params[1];
		LocatorVO locatorVO=new LocatorVO(params[0]);
		
		if(params[0].isEmpty())
		{
			result.setDefectDesc("Locator not provided !");
			return result;
		}
		WebElement textBoxObj=null;
		try {
			//textBoxObj = AutomationUtil.getElement(webDriver, locatorVO);
			//String actualValue=textBoxObj.getAttribute("value");
			

			((JavascriptExecutor) webDriver).executeScript(
					"arguments[0].value='';",textBoxObj);
			String actualValue = textBoxObj.getText();
			
			System.out.println(actualValue);
			if(actualValue.equalsIgnoreCase(expectedValue))
			{
				result.setStatus(1);
			}
			else
			{
				result.setDefectDesc("text in not matching exp : "+expectedValue+ " Act: "+actualValue);

			}
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}
		return result;
	}

}
