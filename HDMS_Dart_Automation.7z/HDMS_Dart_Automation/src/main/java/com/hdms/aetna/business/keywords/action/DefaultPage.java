package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class DefaultPage implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();
		try {

			//objectToGettext = AutomationUtil.getElement(webDriver, locatorVO);
			webDriver.switchTo().defaultContent();


			

			//System.out.println(objectToGettext.getText());

		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}


		result.setStatus(Constants.PASS);
		return result;
	}

}
