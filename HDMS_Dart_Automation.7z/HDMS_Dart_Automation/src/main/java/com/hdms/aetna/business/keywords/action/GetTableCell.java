package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class GetTableCell implements KeywordInterface
{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {

		TestStepExecutionResultVO  testStepExecutionResultVO = new TestStepExecutionResultVO();


		try {
			WebElement dataTable = AutomationUtil.getElement(webDriver, params[0]);

			int row = Integer.parseInt(params[1])-1;

			int col =  Integer.parseInt(params[2])-1;

			WebElement singleCell =  dataTable.findElements(By.tagName("tr")).get(row).findElements(By.tagName("td")).get(col);

			System.out.println("Cell Value ["+row+"]["+col+"]........"+singleCell.getText());


		} catch (HDMSException e) {	
			testStepExecutionResultVO.setDefectDesc("Not able to click cell");
	

			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(1);
		return testStepExecutionResultVO;

	}
}
