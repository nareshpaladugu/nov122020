package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class Clear implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String testBox = param[0];
		LocatorVO locatorVO=new LocatorVO(testBox);
		WebElement textBoxObj=null;


		
			try {
				
				textBoxObj = AutomationUtil.getElement(webDriver, locatorVO);
				textBoxObj.clear();
				System.out.println("");
				
			} catch (Exception e) {

				result.setDefectDesc(e.getMessage());
				return result;

			}	

		result.setStatus(Constants.PASS);
		return result;
	}

}
