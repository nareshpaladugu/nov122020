package com.hdms.aetna.utils;

public class SecondClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TestClass.testMethod("4", "5", "6");
		
		TestClass.testMethod("4", "5", "6","7");
		
		TestClass.testMethod("4", "5", "6","8","9");
	}

}
