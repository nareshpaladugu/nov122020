package com.hdms.aetna.business.keywords.application;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class RemoveTest implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();
		String type = params[0];

		try
		{

			int numberOfDeletedElements  = 0;

			List<WebElement> allDeleteRowDimButtons = null;

			//allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'Row Dimensions')]/../.."+ "//div[contains(@class,'v-slot-nx-report-designer-draggable-item-remove')]"));
			if(type.toLowerCase().contains("analysis")) {
			//allDeleteRowDimButtons =webDriver.findElements(By.xpath("//span[contains(@class,'v-icon FontAwesome')]"));
			allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'AnalysisGroup')]"));
			}
			
			numberOfDeletedElements = allDeleteRowDimButtons.size();

			for (int i = 0; i <numberOfDeletedElements; i++) {

				//allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'Row Dimensions')]/../.."+ "//div[contains(@class,'v-slot-nx-report-designer-draggable-item-remove')]"));
				allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'AnalysisGroup')]/../..//div[@role='button']"));
				
				if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty())
				{
					
					allDeleteRowDimButtons.get(0).click();
					webDriver.findElement(By.xpath("//span[contains(text(),'Delete')]")).click();
					webDriver.findElement(By.xpath("//span[text()='Yes']")).click();
					
					//Thread.sleep(1000);
				}
			}
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	 
	}

}
