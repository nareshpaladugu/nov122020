package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class SelectListValue implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO=new TestStepExecutionResultVO();

		String type = params[2];
		type=type==null||type.isEmpty()?"text":type;

		if(params[0].isEmpty())
		{
			testStepExecutionResultVO.setDefectDesc("Object locator not given");

			return testStepExecutionResultVO;
		}
		LocatorVO locatorVO=new LocatorVO(params[0]);

		WebElement dropDownListBox=null;
		try {
			dropDownListBox = AutomationUtil.getElement(webDriver, locatorVO);
		} catch (HDMSException e) {

			testStepExecutionResultVO.setDefectDesc(e.getMessage());
			return testStepExecutionResultVO;

		}

		Select selectDropDown = new Select(dropDownListBox);


		try {
			switch (type)
			{
			case "text":
				selectDropDown.selectByVisibleText(params[1]);
				break;

			case "value":
				selectDropDown.selectByValue(params[1]);
				break;

			case "index":
				selectDropDown.selectByIndex(Integer.parseInt(params[1]));
				break;

			default:

				testStepExecutionResultVO.setDefectDesc("Unkown select value type");
				return testStepExecutionResultVO;
			}
		} catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}

		testStepExecutionResultVO.setStatus(1);
		return testStepExecutionResultVO;
	}

}
