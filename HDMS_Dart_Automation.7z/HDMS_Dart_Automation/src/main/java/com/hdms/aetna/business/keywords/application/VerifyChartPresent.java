package com.hdms.aetna.business.keywords.application;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class VerifyChartPresent implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		try
		{

			String param1DvLocContaine =params[0];
			String mainCHartTag = params[1];// like svg etc etc

			String chartSubTags[] = params[2].split(","); // like g or svg etc etc

			WebElement chartContainer = AutomationUtil.getElement(webDriver, new LocatorVO(param1DvLocContaine));

			WebElement actualChart= chartContainer.findElement(By.tagName(mainCHartTag));
			
			if(actualChart==null)
			{
				testStepExecutionResultVO.setDefectDesc("Chart not found "+mainCHartTag);
				return testStepExecutionResultVO;
				//fail
			}
			
			for(String singleTag : chartSubTags)
			{
				try {
					WebElement actualChartSubElement= actualChart.findElement(By.tagName(singleTag));

					if(actualChartSubElement==null)
					{
						testStepExecutionResultVO.setDefectDesc("Chart not found, subelement "+singleTag );
						return testStepExecutionResultVO;
						//fail
					}
				} catch (Exception e) {
					testStepExecutionResultVO.setDefectDesc("Chart not found, subelement "+singleTag );
					return testStepExecutionResultVO;
				}
			}
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Chart not found");
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}

}
