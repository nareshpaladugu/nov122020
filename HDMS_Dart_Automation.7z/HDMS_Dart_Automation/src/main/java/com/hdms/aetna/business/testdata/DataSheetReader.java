package com.hdms.aetna.business.testdata;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.format.CellDateFormatter;
import org.apache.poi.ss.usermodel.Cell;

import com.hdms.aetna.utils.HDMSConstants;
import com.hdms.aetna.utils.HDMSException;

public class DataSheetReader {


	public static Map<String, String> readObjectRepo(String sWorkBook)
	{

		Map<String, String>  objectMap = new HashMap<String, String>();

		if(sWorkBook==null || sWorkBook.isEmpty())
			return objectMap;

		File file =new File(sWorkBook);

		try {
			ExcelHandler excelHandler = new ExcelHandler();
			org.apache.poi.ss.usermodel.Workbook workbook = excelHandler.getWorkbookSheet(file);


			org.apache.poi.ss.usermodel.Sheet sheet  = workbook.getSheetAt(0);

			int rows = sheet.getPhysicalNumberOfRows();

			for (int i = 1; i <rows; i++) 
			{
				org.apache.poi.ss.usermodel.Row row = sheet.getRow(i);

				String logicalName = getCellValue(row.getCell(0));

				String actualLocator = getCellValue(row.getCell(1));

				objectMap.put(logicalName, actualLocator);
			}
		} catch (HDMSException e) {
			e.printStackTrace();
			return objectMap;
		}

		System.out.println("objectMap size..............."+objectMap.size());
		return objectMap;
	}

	public static 	Map<String, Map<String, Map<String, String>>> readDataSheets(String sWorkBook) throws HDMSException
	{
		Map<String, Map<String, Map<String, String>>>workBookMap = new LinkedHashMap<String, Map<String,Map<String,String>>>();

		Map<String, String> rowMap = null;

		Map<String, Map<String, String>> sheetMap =	null;

		File file =new File(sWorkBook);

		String header[]=null;

		int iNoOfSheets=0;

		ExcelHandler excelHandler = new ExcelHandler();

		try 
		{
			org.apache.poi.ss.usermodel.Workbook workbook = excelHandler.getWorkbookSheet(file);

			int actualDataCols[];

			iNoOfSheets = workbook.getNumberOfSheets();

			for(int s=0;s<iNoOfSheets;s++)
			{
				org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(s);

				sheetMap =	new LinkedHashMap<String,  Map<String, String>>();

				if (sheet != null) 
				{
					org.apache.poi.ss.usermodel.Row row = sheet.getRow(0);

					if (row != null) 
					{						
						int totalColums= row.getLastCellNum();
						int actualDataColsCount=-1;

						header=new String[totalColums];
						actualDataCols=new int[totalColums];

						for(int i=0;i<totalColums;i++)
						{
							if(row.getCell(i)!=null && !(row.getCell(i).toString().trim().equals("")))
							{
								actualDataCols[++actualDataColsCount]=i;
							}
						}

						actualDataColsCount++;

						header=new String[actualDataColsCount];

						for(int i=0;i<actualDataColsCount;i++)
						{
							String cellValue = getCellValue(row.getCell(actualDataCols[i]));
							header[i] = cellValue.trim();
						}

						int iRowNumbers = sheet.getLastRowNum();

						for(int i=1;i<=iRowNumbers;i++)
						{
							rowMap=new LinkedHashMap<String, String>();
							row = sheet.getRow(i);

							for(int col=0;col<actualDataColsCount;col++)
							{
								try 
								{
									String cellValue = getCellValue(row.getCell(actualDataCols[col]));

									rowMap.put(header[col], cellValue);

								} catch (Exception e) 
								{
									rowMap.put(header[col],"");
								}
							}

							sheetMap.put(String.valueOf(i), rowMap);
						}

						workBookMap.put(sheet.getSheetName(), sheetMap);
					}
				}
			}
		} catch (HDMSException e) 
		{
			//e.printStackTrace();
			throw e;
		}
		finally
		{
			excelHandler.closeWorkBook();
		}

		return workBookMap;
	}

	public static String getCellValue(org.apache.poi.ss.usermodel.Cell cell) 
	{

		String value = HDMSConstants.EMPTY_STRING;

		if (cell != null) 
		{
			int cellType = cell.getCellType();

			switch (cellType) 
			{

			case Cell.CELL_TYPE_STRING:

				value = cell.getRichStringCellValue().toString();

				if (value.contains("password")) 
				{
					// value = encode(value);
				}

				break;

			case Cell.CELL_TYPE_NUMERIC:

				if (HSSFDateUtil.isCellDateFormatted(cell))
				{
					Date date2 = cell.getDateCellValue();
					String dateFmt = cell.getCellStyle().getDataFormatString();
					value = new CellDateFormatter(dateFmt).format(date2);
				}else
				{
					cell.setCellType(HSSFCell.CELL_TYPE_STRING);
					value = cell.getStringCellValue();
				}

				break;

			case Cell.CELL_TYPE_BOOLEAN:

				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				value = cell.getStringCellValue();
				break;

			case Cell.CELL_TYPE_BLANK:

				value = HDMSConstants.EMPTY_STRING;
				break;

			default:

				return value;
			}
		} else 
		{
			return value;
		}

		return value;
	}

}
