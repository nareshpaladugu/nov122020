package com.hdms.aetna.business.keywords;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class TemplateKeyword implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {
		
		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();
		
		try
		{
			
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);
		
		return testStepExecutionResultVO;	
	}

}
