package com.hdms.aetna.business.keywords.js;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.utils.LoadProperties;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class DoubleClickByJs implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		try
		{

			WebDriverWait wait = new WebDriverWait(webDriver, Integer.parseInt(LoadProperties.OBJECT_LOAD_TIME));

			System.out.println("finding the element [double click js]");
			WebElement element = AutomationUtil.getElement(webDriver, params[0]);

			System.out.println("Got the element,waiting for clickable [double click js]");
			element =  wait.until(ExpectedConditions.elementToBeClickable(element));

			System.out.println("object is clickable");

			try {
				((JavascriptExecutor) webDriver).executeScript(
						"var evt = document.createEvent('MouseEvents'); 	"
								+ " evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false,	"
								+ "	false, 0,null); arguments[0].dispatchEvent(evt);",element);
			}
			catch(org.openqa.selenium.StaleElementReferenceException e)
			{
				((JavascriptExecutor) webDriver).executeScript(
						"var evt = document.createEvent('MouseEvents'); 	"
								+ " evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false,	"
								+ "	false, 0,null); arguments[0].dispatchEvent(evt);",AutomationUtil.getElement(webDriver, params[0]));
			}
		}
		catch (HDMSException e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}

		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}

}
