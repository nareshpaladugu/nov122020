package com.hdms.aetna.business.keywords.browser;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class CloseBrowser implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO=new TestStepExecutionResultVO();
		try {
			
			webDriver.close();
			webDriver.quit();

		} catch (Exception e2) {

			testStepExecutionResultVO.setDefectDesc(e2.getMessage());
			return testStepExecutionResultVO;

		}

		testStepExecutionResultVO.setStatus(1);
		return testStepExecutionResultVO;
	}

}
