package com.hdms.aetna.business.keywords.js;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class SetAttributeValue implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String locator = param[0];

		String attribute = param[1];

		
		String attrVal = param[2];

		LocatorVO locatorVO=new LocatorVO(locator);

		WebElement object=null;
		try {
			object = AutomationUtil.getElement(webDriver, locatorVO);



			((JavascriptExecutor) webDriver).executeScript("arguments[0].arguments[1]=arguments[2];", object,attribute,attrVal);


		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;
		}

		result.setStatus(Constants.PASS);
		return result;
	}

}
