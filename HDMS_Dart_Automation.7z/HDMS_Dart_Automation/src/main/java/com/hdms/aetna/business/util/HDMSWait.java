package com.hdms.aetna.business.util;

/**
 * @author ddaphal
 *
 */
public class HDMSWait
{
	public HDMSWait()
	{
	}
	
	public void waitFor(long milliSeconds)
	{

		try {
			Thread.sleep(milliSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
