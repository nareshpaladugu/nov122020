package com.hdms.aetna.sam;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FireOpen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   WebDriver myD=new FirefoxDriver();
   myD.get("https://www.facebook.com/");
	}

}
