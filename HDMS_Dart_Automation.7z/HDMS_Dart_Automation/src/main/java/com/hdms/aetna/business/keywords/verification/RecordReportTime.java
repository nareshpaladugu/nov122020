package com.hdms.aetna.business.keywords.verification;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class RecordReportTime implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params)
	{
		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		try
		{
			//double click
			((JavascriptExecutor) webDriver).executeScript(
					"var evt = document.createEvent('MouseEvents'); 	"
							+ " evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false,	"
							+ "	false, 0,null); arguments[0].dispatchEvent(evt);",AutomationUtil.getElement(webDriver, params[0]));


			long startTime = System.currentTimeMillis();

			System.out.println("Start time recorded : "+startTime);

			//select window

			int  index = 2;

			try {


				Set<String> set = webDriver.getWindowHandles();

				int changeCount = 0;

				for (Iterator<String> iterator = set.iterator(); iterator.hasNext();) 
				{
					String handle = (String) iterator.next();
					webDriver.switchTo().window(handle);

					System.out.println("Browser Title ...."+webDriver.getTitle());
					changeCount++;

					if(changeCount==index)
						break;
				}

			} catch (Exception ex) {
				testStepExecutionResultVO.setDefectDesc(ex.getMessage());
				return testStepExecutionResultVO;
			}

			finally {
			}


			LocatorVO locatorTableVO=new LocatorVO(params[1]);

			try {
				WebDriverWait wait = new WebDriverWait(webDriver, 300);

				//wait for either table or button
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locatorTableVO.getLocator())));
			} catch (Exception e) {

				testStepExecutionResultVO.setDefectDesc("Report not loaded within given max  timeload");

				return testStepExecutionResultVO;
			}

			WebElement eleTableOrButton = webDriver.findElement(By.xpath(locatorTableVO.getLocator()));

			if(!eleTableOrButton.getTagName().equalsIgnoreCase("table"))
			{
				eleTableOrButton.click();

				try {
					webDriver.findElement(By.xpath(locatorTableVO.getLocator()));
				} catch (Exception e) {
					testStepExecutionResultVO.setDefectDesc("Report not found");
					return testStepExecutionResultVO;
				}
			}

			long stopTime = System.currentTimeMillis();

			System.out.println("Stop time recorded : "+startTime);

			long millis=stopTime-startTime;

			System.out.println("Actual time diff in millis : "+millis);

			long second = (millis / 1000) % 60;
			long minute = (millis / (1000 * 60)) % 60;
			long hour = (millis / (1000 * 60 * 60)) % 24;

			long seconds=TimeUnit.MILLISECONDS.toSeconds(millis);
			System.out.println("this is naresh seconds-------"+seconds);

			String time = String.format("%02d:%02d:%02d", hour, minute, second);

			System.out.println("Report took(hh:mm:ss) : "+time);

			testStepExecutionResultVO.setTestData("Report took(hh:mm:ss) : "+time);


		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}

		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;

	}

}
