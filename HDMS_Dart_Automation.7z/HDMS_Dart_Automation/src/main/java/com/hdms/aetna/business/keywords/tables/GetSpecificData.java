package com.hdms.aetna.business.keywords.tables;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class GetSpecificData implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();
		String value = params[1];


		try
		{

			
			WebElement table = AutomationUtil.getElement(webDriver, params[0]);

			WebElement header = table.findElement(By.tagName("thead"));

			WebElement headerRow = header.findElement(By.tagName("tr"));

			List<WebElement> allColInHeader = headerRow.findElements(By.tagName("th"));

			for (WebElement singleHeaderCell : allColInHeader) {

				System.out.print(singleHeaderCell.getText()+",");

				
			}


			System.out.println("\n");

			WebElement tbodyData = table.findElement(By.tagName("tbody"));

			List<WebElement> allActualDataRows = tbodyData.findElements(By.tagName("tr"));

			for (WebElement singleRowData : allActualDataRows) {

				List<WebElement> allCOlFromSingleRow = singleRowData.findElements(By.tagName("td"));

				for (WebElement singleDataCell : allCOlFromSingleRow) {
					System.out.println("--------------------------------------------------------------------");
					
					if(singleDataCell.getText().equals(value)) {
						singleDataCell.click();
						System.out.println("this is naresh text"+singleDataCell.getText());
						
					}
					
					//System.out.print(singleDataCell.getText()+",");
					

				
				}

				

				System.out.println("");
				
			}

			System.out.println("");


			System.out.println("Done");


		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		

		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}

}
