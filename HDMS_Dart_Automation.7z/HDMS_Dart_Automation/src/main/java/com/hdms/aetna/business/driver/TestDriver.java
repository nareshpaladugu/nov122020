package com.hdms.aetna.business.driver;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.handlefailure.HandlerFailures;
import com.hdms.aetna.business.keywords.browser.LaunchBrowser;
import com.hdms.aetna.business.testdata.DataSheetReader;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.business.util.KeywordFactoryImpl;
import com.hdms.aetna.email.EmailUtils;
import com.hdms.aetna.reader.TestReader;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSConstants;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.utils.LoadProperties;
import com.hdms.aetna.utils.ResultUtil;
import com.hdms.aetna.utils.ResultVO;
import com.hdms.aetna.vos.BusinessProcessVO;
import com.hdms.aetna.vos.SingleTestStepVO;
import com.hdms.aetna.vos.TestStepExecutionResultVO;
import com.hdms.aetna.vos.TestVO;

/**
 * @author Naresh Paladugu
 *
 */
public class TestDriver {

	@Test(dataProvider="scriptProvider")
	public void driverTest(String sTestFileName)
	{
		System.out.println("Executing test : "+sTestFileName);

		AutomationUtil.checkTempFolder();

		ResultVO resultvo=new ResultVO();

		List<BusinessProcessVO> listOfBusniessProcesses=new LinkedList<BusinessProcessVO>();

		resultvo.setScriptName(sTestFileName);

		int totalFaliedTests = 0;
		int totalPassedTests = 0;

		WebDriver webDriver=null;

		TestVO testvo=null;
		try {
			testvo = TestReader.readTest(sTestFileName);

			LinkedList<BusinessProcessVO> driverRows = testvo.getDriverRows(); 
			//order

			TestStepExecutionResultVO testStepExecutionResultVO= null;

			Map<String, Map<String, Map<String, String>>>dataMap = new HashMap<String, Map<String,Map<String,String>>>();

			Map<String,String> objectRepository = new HashMap<String, String>();
			Map<String, String> rowNumberConfigurationMap = new HashMap<String,String>();

			boolean exitFlag = false;

			boolean stopFlag = false;

			int totalBizCount=0;

			for (BusinessProcessVO businessProcess : driverRows) {

				if(!businessProcess.getToBeExecuted().equalsIgnoreCase("X") && !businessProcess.getToBeExecuted().equalsIgnoreCase("N"))
				{
					totalBizCount++;
				}
			}

			int curBizCounter = 0;


			int curTestStepCounter=0;

			int failStepCounter=0;
			
			for (BusinessProcessVO businessProcess : driverRows) {

				if(!businessProcess.getToBeExecuted().equalsIgnoreCase("X") && !businessProcess.getToBeExecuted().equalsIgnoreCase("N"))
				{
					curBizCounter++;
					businessProcess.setExecuted(true);

					if(!businessProcess.getTestDataFile().isEmpty())
					{
						try {

							//Read Input Data if any

							dataMap= DataSheetReader.readDataSheets(businessProcess.getTestDataFile());

							//Read object repo if any

							objectRepository.putAll(DataSheetReader.readObjectRepo(businessProcess.getObjectRepo()));

							System.out.println("Test object repo size............... "+objectRepository.size());
							Set<String> sheets = dataMap.keySet();

							for (String sheet : sheets) {

								if(businessProcess.getRowNumber().isEmpty())
								{
									//default row number is 1
									rowNumberConfigurationMap.put(sheet, "1");
								}
								else
								{
									rowNumberConfigurationMap.put(sheet, businessProcess.getRowNumber());
								}
							}

						} catch (HDMSException e) {

							businessProcess.setMessages(e.getMessage());
						}
					}

					LinkedList<TestStepExecutionResultVO> listOfExecutionsSteps=new LinkedList<TestStepExecutionResultVO>();
					Integer passedSoFar = 0;
					Integer failedSoFar = 0;
					Integer skippedSoFar = 0;

					businessProcess.setPassedTests(0);
					businessProcess.setFailedTest(0);
					businessProcess.setSkippedTests(0);

					businessProcess.setStartCalendar(Calendar.getInstance());

					LinkedList<SingleTestStepVO> testSteps =	businessProcess.getTestSteps();

					int startIt = businessProcess.getStartIt();
					int stopIt = businessProcess.getStopIt();

					if(startIt==-1)
					{
						startIt=1;
					}
					startIt--;

					if(stopIt==-1)
					{
						stopIt=businessProcess.getTestSteps().size();
					}

					stopIt--;


					exitFlag = false;

					curTestStepCounter=0;
					for (int iCurrentTestStepNumber = startIt; iCurrentTestStepNumber <=stopIt; iCurrentTestStepNumber++) {

						curTestStepCounter++;

						SingleTestStepVO singleTestStepVO = testSteps.get(iCurrentTestStepNumber);

						System.out.println("Executing... [biz process "+curBizCounter+" of "+totalBizCount + "], Test Step "+curTestStepCounter+ " of "+testSteps.size()+" ["+singleTestStepVO.getAction()+"-"+singleTestStepVO.getParam1()+"]");

						if(!singleTestStepVO.getToBeExecuted().equalsIgnoreCase("X"))
						{

							Calendar testStartCal= Calendar.getInstance();

							if(singleTestStepVO.getAction().isEmpty())
							{
								continue;
							}

							if(singleTestStepVO.getAction().equalsIgnoreCase("LaunchBrowser"))
							{
								LaunchBrowser launchBrowser = new LaunchBrowser();

								try {
									testStepExecutionResultVO = launchBrowser.execute(null, singleTestStepVO.getParamsList(dataMap, rowNumberConfigurationMap,objectRepository));
								} catch (HDMSException e) {

									testStepExecutionResultVO.setDefectDesc(e.getMessage());
								}

								resultvo.setBrowser(singleTestStepVO.getParam2());

								webDriver = launchBrowser.getWebDriverInstance();
							}
							else
							{
								//this is called as reflection
								KeywordInterface keyword = KeywordFactoryImpl.getInstance().get(singleTestStepVO.getAction());

								if(keyword==null)
								{
									testStepExecutionResultVO = new TestStepExecutionResultVO();
									testStepExecutionResultVO.setDefectDesc("Unknown Keyword"+singleTestStepVO.getAction());
									System.out.println("Unknown Keyword........");
								}
								else
								{
									try {
										//main line
										testStepExecutionResultVO = keyword.execute(webDriver, singleTestStepVO.getParamsList(dataMap, rowNumberConfigurationMap,objectRepository));
									} catch (HDMSException e) {

										testStepExecutionResultVO.setDefectDesc(e.getMessage());
									}
								}

							}

							switch (testStepExecutionResultVO.getStatus()) 
							{
							case HDMSConstants.PASS:

								passedSoFar++;
								businessProcess.setPassedTests(passedSoFar);
								totalPassedTests++;

								break;

							case HDMSConstants.FAIL:

								failedSoFar++;
								businessProcess.setFailedTest(failedSoFar);
								totalFaliedTests++; 

								if(LoadProperties.CaptureBitmapOnFailure)
								{
									HandlerFailures.captureBitmapHandler(webDriver, sTestFileName, businessProcess,
											singleTestStepVO, testStepExecutionResultVO);
								}

								String sActionOnFail  = singleTestStepVO.getActionOnFail();

								if(sActionOnFail.equalsIgnoreCase(HDMSConstants.ACTION_ON_FAIL_EXIT))
								{
									exitFlag = true;
									testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc() + ", EXIT the current scenario");
								}
								else if(sActionOnFail.equalsIgnoreCase(HDMSConstants.ACTION_ON_FAIL_STOP))
								{
									stopFlag = true;

									testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc() + ", STOP the Execution");

								}
								else if(sActionOnFail.equalsIgnoreCase(HDMSConstants.ACTION_ON_FAIL_JUMP))
								{
									String sActionOnFailRow = singleTestStepVO.getActionOnFailParam();

									if(sActionOnFailRow.isEmpty())
									{
										testStepExecutionResultVO.setStatus(0);
										testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc()+" Action On Fail - Jump row not specified");
									}
									else
									{
										try {
											int jumpRow = Integer.parseInt(sActionOnFailRow);

											if(jumpRow>stopIt)
											{
												testStepExecutionResultVO.setStatus(0);
												testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc()
														+" Action On Fail - Invalid Jump row specified :"+sActionOnFailRow+ ", It should be less than stop iteration");
											}
											else
											{
												iCurrentTestStepNumber=jumpRow-2;
											}

										} catch (NumberFormatException e) {


											testStepExecutionResultVO.setStatus(0);
											testStepExecutionResultVO.setDefectDesc(testStepExecutionResultVO.getDefectDesc()
													+" Action On Fail - Invalid Jump row specified :"+sActionOnFailRow);
										}


									}

								}

								break;

							case HDMSConstants.SKIPPED:

								skippedSoFar++;
								businessProcess.setSkippedTests(skippedSoFar);
								//totalSkippedTest++;
								break;
							}

							if(testStepExecutionResultVO.getTestData().isEmpty())
								testStepExecutionResultVO.setTestData(singleTestStepVO.getParamForTestData());

							testStepExecutionResultVO.setTestCaseID(singleTestStepVO.getTeststep());
							testStepExecutionResultVO.setExecutionTimeStr(AutomationUtil.getExecutionTimingString(Calendar.getInstance()));
							testStepExecutionResultVO.setStepDescription(singleTestStepVO.getStepDescription());

							testStepExecutionResultVO.setStartCalendar(testStartCal);
							testStepExecutionResultVO.setStopCalendar(Calendar.getInstance());

							listOfExecutionsSteps.add(testStepExecutionResultVO);

							
							
							if(testStepExecutionResultVO.getStatus()==HDMSConstants.FAIL)
							{
								failStepCounter++;
								//inc fail ctr
							}
							
							if(failStepCounter==LoadProperties.FAIL_THR)
							{
								stopFlag=true;
							}
							
							if(testStepExecutionResultVO.getStatus()==1 && !singleTestStepVO.getAction().equalsIgnoreCase("wait")) {
								
								failStepCounter=0;
								//reset fail ctr for non wait keyword
							}
							
							if(exitFlag || stopFlag)
							{
								break;
							}
						}	
					}

					businessProcess.setStopCalendar(Calendar.getInstance());
					businessProcess.setTestCaseExecutionList(listOfExecutionsSteps);

					listOfBusniessProcesses.add(businessProcess);	

					if(stopFlag)
					{
						break;
					}
				}
			}

			resultvo.setListOfBusniessProcesses(listOfBusniessProcesses);

			String sTestName = AutomationUtil.shortenTestName(sTestFileName);


			String sResultFileName ="./Results/"+sTestName+"_"+ResultUtil.getTimeStamp()+".xls";

			ResultUtil.generateExcelResult(resultvo,sResultFileName);

			if(LoadProperties.CaptureBitmapOnFailure && totalFaliedTests!=0)
			{
				HandlerFailures.generatFailureReport(sTestName+"_"+ResultUtil.getTimeStamp());
			}

			if(LoadProperties.EMAIL_FLAG)
			{
				EmailUtils.sendAutoEmail(sTestName, sResultFileName, totalPassedTests, totalFaliedTests, ResultUtil.calculateTotalTime(listOfBusniessProcesses));
			}

		} catch (HDMSException e1) {
			e1.printStackTrace();
		}
		finally
		{
			if(webDriver!=null)
			{
				try {
					//webDriver.quit();
				} catch (Exception e) {
				}
			}
		}
	}


	@DataProvider(name="scriptProvider", parallel=true)
	public Object[][] scriptProvider(){

		String files = LoadProperties.LST_FILES;
		String[] lstFiles= files.split(",");
		Object[][] lstOfFiles = new Object[lstFiles.length][1];
		int i = 0;
		for(String sFileName : lstFiles){
			lstOfFiles[i++] = new Object[]{LoadProperties.LST_FILES_FOLDER+sFileName};
		}
		return lstOfFiles;
	}
}
