package com.hdms.aetna.utils;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class NewTrailkeyword implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		// TODO Auto-generated method stub
		
		//sdfsdf
		//sdas
		return null;
	}

	

}
