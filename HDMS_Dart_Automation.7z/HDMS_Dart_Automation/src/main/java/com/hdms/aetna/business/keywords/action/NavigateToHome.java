package com.hdms.aetna.business.keywords.action;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class NavigateToHome implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {

		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		try {
			Thread.sleep(500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		webDriver.findElement(By.xpath("//div[contains(@class,'indexbreadcrumbs')]"));
		
		List<WebElement> navLinksArray = webDriver.findElements(By.xpath("//div[contains(@class,'indexbreadcrumbs')]//span[contains(@class,'v-button-caption')]"));

		String txt =navLinksArray.get(0).getText();
		System.out.println("\n navLinksArray.. size....... "+navLinksArray.size());
		
		System.out.println("First button caption... "+txt);
		
		if(navLinksArray.size()>=2  && !txt.equalsIgnoreCase("Home"))
		{
			//Home nav should work

			LocatorVO locatorVO=new LocatorVO("//div[contains(@class,'indexbreadcrumbs')]//span[contains(@class,'v-menubar-menuitem')]");

			WebElement objectToClick=null;
			try {

				objectToClick = AutomationUtil.getElement(webDriver, locatorVO);

				objectToClick.click();

				objectToClick = AutomationUtil.getElement(webDriver, new LocatorVO("//img[contains(@src,'home.png')]"));

				objectToClick.click();

			} catch (Exception e) {

				result.setDefectDesc(e.getMessage());
				return result;

			}

		}
		else
		{
			//home nav not possible
		}



		result.setStatus(Constants.PASS);
		return result;
	}

}
