package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class EnterTextValueAjax implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String testBox = param[0];
		String valueToenter = param[1];

		LocatorVO locatorVO=new LocatorVO(testBox);
		WebElement textBoxObj=null;
		try {
			
			textBoxObj = AutomationUtil.getElement(webDriver, locatorVO);
			String actualValue=textBoxObj.getText();
			
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}

		try {
			textBoxObj.clear();

			Thread.sleep(1000);
			
			Actions actions = new Actions(webDriver);			
			actions.moveToElement(textBoxObj).sendKeys(valueToenter).build().perform();
			
			System.out.println("");

			System.out.println("text after enter ..."+textBoxObj.getAttribute("value"));

			if(!param[2].isEmpty() && param[2].equalsIgnoreCase("true"))
			{
				//textBoxObj.sendKeys(Keys.TAB);
				textBoxObj.sendKeys(Keys.ENTER);
			}
			
			Thread.sleep(1000);

			System.out.println("");
		} catch (Exception e) {
			result.setDefectDesc(e.getMessage());
			return result;
		}

		result.setStatus(Constants.PASS);
		return result;
	}

}
