package com.hdms.aetna.business.keywords.getter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;


public class GetTextValue implements KeywordInterface {

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... params) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();
		LocatorVO locatorVO=new LocatorVO(params[0]);
		WebElement textBoxObj=null;

		try 
		{
			textBoxObj = AutomationUtil.getElement(webDriver, locatorVO);

			String actualValue;
			
			if(params[1].isEmpty())
			{
				actualValue=textBoxObj.getText();
			}
			else {
				actualValue=textBoxObj.getAttribute("value");
			}

			result.setTestData("Extracted Value : \""+actualValue+"\"");

			result.setStatus(Constants.PASS);
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}
		return result;
	}

}
