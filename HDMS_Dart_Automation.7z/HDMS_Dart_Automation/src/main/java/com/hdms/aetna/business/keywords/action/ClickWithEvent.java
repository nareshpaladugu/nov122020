package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class ClickWithEvent implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String locator = param[0];

		LocatorVO locatorVO=new LocatorVO(locator);

		WebElement objectToClick=null;
		try {
			objectToClick = AutomationUtil.getElement(webDriver, locatorVO);
		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;

		}

		System.out.println("ClickWithEvent... "+locator);
		try {

			((JavascriptExecutor) webDriver).executeScript("return arguments[0].click()",objectToClick);

		}
		catch(StaleElementReferenceException ee)
		{
			try {
				objectToClick = AutomationUtil.getElement(webDriver, locatorVO);
				((JavascriptExecutor) webDriver).executeScript("return arguments[0].click()",objectToClick);
			} catch (Exception e) {
			}
		}	
		catch (Exception e) {
			e.printStackTrace();
			result.setDefectDesc(e.getMessage());
			return result;
		}

		result.setStatus(Constants.PASS);
		return result;
	}

}
