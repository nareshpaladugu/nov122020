package com.hdms.aetna.business.keywords.action;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.LoadProperties;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class WaitForReportsToLoad_New implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		int largestWaitTime = 2400; //Sec
		WebElement objectToClick=null;
		try
		{

			System.out.println("WaitForReportsToLoad_New... keyword started !");

			System.out.println("Wait for apply ...");
			waitForElementPresent(webDriver, By.xpath("//span[text()='Apply']"));

			webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

			
			System.out.println("Click apply ...");
			objectToClick = AutomationUtil.getElement(webDriver, "//span[text()='Apply']");
			//AutomationUtil.getElement(webDriver, "//span[text()='Apply']").click();
			
			((JavascriptExecutor) webDriver).executeScript("arguments[0].click();", objectToClick);

			System.out.println("Wait for apply to gone...");
			waitForElementDisap(webDriver,By.xpath("//span[text()='Apply']"));

			System.out.println("Apply Button gone !");

			webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

			WebElement statusElement;

			statusElement = AutomationUtil.getElement(webDriver, "//div[@id='nx-dashboard-status']");

			String str_data_total_cells = statusElement.getAttribute("data-total-cells");

			System.out.println("str_data_total_cells...... "+str_data_total_cells);

			int iDataCellsExp = Integer.parseInt(str_data_total_cells);

			int iDataCellAct=-1;

			int retryCount=1;


			while(iDataCellsExp!=iDataCellAct)
			{
				iDataCellAct = Integer.parseInt(statusElement.getAttribute("data-cells-complete"));

				System.out.println("iDataCellAct [retry :"+retryCount+"]........."+iDataCellAct);

				Thread.sleep(1000);

				retryCount++;

				if(retryCount==largestWaitTime)
				{
					break;
				}
			}

			if(iDataCellsExp==iDataCellAct)
			{
				System.out.println("Got match data-total-cells =  data-cells-complete");
				testStepExecutionResultVO.setStatus(Constants.PASS);
			}

		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		finally
		{
			webDriver.manage().timeouts().implicitlyWait(Integer.parseInt(LoadProperties.OBJECT_LOAD_TIME), TimeUnit.SECONDS);
		}


		return testStepExecutionResultVO;	
	}



	private void waitForElementPresent(WebDriver webDriver,By by)
	{
		WebDriverWait wait = new WebDriverWait(webDriver, 2200);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
	}

	private void waitForElementDisap(WebDriver webDriver,By by)
	{
		WebDriverWait wait = new WebDriverWait(webDriver, 2200);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}
}
