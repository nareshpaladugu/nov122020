package com.hdms.aetna.business.util;

public class Constants {

	public static final int PASS=1;

}
