package com.hdms.aetna.business.keywords.application;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class RemoveStoryChrome implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... param) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();
		String type = param[0];
		try
		{

			int numberOfDeletedElements  = 0;

			List<WebElement> allDeleteRowDimButtons = null;
			
			if(type.toLowerCase().contains("story")) {

			allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'StoryBo')]"));
			}else if(type.toLowerCase().contains("grouping")) {
				
				allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'DYGrouping')]"));
			}else if(type.toLowerCase().contains("banding")) {
				allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'AGBanding')]"));
			}
			else {
				allDeleteRowDimButtons =webDriver.findElements(By.xpath("//div[contains(text(),'ReportGroup')]"));
			}
			
			numberOfDeletedElements = allDeleteRowDimButtons.size();

			for (int i = 0; i <= numberOfDeletedElements; i++) {
				if(type.toLowerCase().contains("story")) {

				allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'StoryBo')]/../..//div[@role='button']"));
				
				if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty() && numberOfDeletedElements>0)
				{
					
					allDeleteRowDimButtons.get(0).click();
					webDriver.findElement(By.xpath("//span[text()='Remove']")).click();
					Thread.sleep(2000);
					((JavascriptExecutor) webDriver).executeScript("arguments[0].click();", webDriver.findElement(By.xpath("//span[text()='Yes']")));
					Thread.sleep(2000);
					
				}
				}
				else if(type.toLowerCase().contains("grouping")) {

					allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'DYGrouping')]/../..//div[@role='button']"));
					
					if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty() && numberOfDeletedElements>0)
					{
						
						allDeleteRowDimButtons.get(0).click();
						webDriver.findElement(By.xpath("//span[contains(text(),'Delete')]")).click();
						webDriver.findElement(By.xpath("//span[text()='Yes']")).click();
						Thread.sleep(2000);
					}
					}else if(type.toLowerCase().contains("banding")) {

						allDeleteRowDimButtons = webDriver.findElements(By.xpath("//div[contains(text(),'AGBanding')]/../..//div[@role='button']"));
						
						if(allDeleteRowDimButtons!=null && !allDeleteRowDimButtons.isEmpty() && numberOfDeletedElements>0)
						{
							
							allDeleteRowDimButtons.get(0).click();
							webDriver.findElement(By.xpath("//span[contains(text(),'Delete')]")).click();
							webDriver.findElement(By.xpath("//span[text()='Yes']")).click();
							Thread.sleep(2000);
						}
						}else{

						System.out.println("No Saved Dimensions");
						}
			}
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	 
	}

}
