package com.hdms.aetna.business.keywords.browser;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class ClickAlertKeyword implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		String action = params[0];

		action=action==null||action.isEmpty()?"dismiss":action;

		try {
			switch (action)
			{
			case "accept":
				Alert a = webDriver.switchTo().alert();
				String value1 = a.getText();
				a.accept();
				break;


			case "dismiss":
				Alert a1 = webDriver.switchTo().alert();
				String value2 = a1.getText();
				a1.dismiss();
				break;

			default:

				testStepExecutionResultVO.setDefectDesc("Unkown alter action");
				return testStepExecutionResultVO;
			}
		} catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}

}
