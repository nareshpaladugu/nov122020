package com.hdms.aetna.business.keywords;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class VerifyTableRowData implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		boolean found=false;
		
		try
		{

			WebElement table = AutomationUtil.getElement(webDriver, params[0]);

			String valueToVerify[] = params[1].split("\\|");

			WebElement tbodyData = table.findElement(By.tagName("tbody"));

			List<WebElement> allActualDataRows = tbodyData.findElements(By.tagName("tr"));

			//loop each row
			for (WebElement singleRowData : allActualDataRows) 
			{

				List<WebElement> allCOlFromSingleRow = singleRowData.findElements(By.tagName("td"));

				int colInd=0;

				//loop thr cols - single row
				for (WebElement singleCell : allCOlFromSingleRow) 
				{
					
					System.out.println("current cell value :"+singleCell.getText());
					
					if(singleCell.getText().trim().equalsIgnoreCase(valueToVerify[colInd].trim()))
					{
						colInd++;  
						
						if(colInd==valueToVerify.length)
						{
							break;
						}
					}
				}


				if(colInd==valueToVerify.length)
				{
					System.out.println("got the exepcted row...");
					found = true;
					break;
				}
			}


		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}

		if(found)
			testStepExecutionResultVO.setStatus(Constants.PASS);
		else
		{
			testStepExecutionResultVO.setDefectDesc("Expected row nor found"+params[1]);
		}
		

		System.out.println("");
		return testStepExecutionResultVO;	
	}

}
