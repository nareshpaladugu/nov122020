package com.hdms.aetna.business.keywords.action;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class SaveFile implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		try
		{

			//alt+s

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_ALT); 
			robot.keyPress(KeyEvent.VK_S); 
			robot.keyRelease(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_ALT);


			//enter
			robot.keyPress(KeyEvent.VK_ENTER); 
			robot.keyRelease(KeyEvent.VK_ENTER);

			System.out.println("Done with robot...");
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}

}
