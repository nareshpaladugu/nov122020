package com.hdms.aetna.business.keywords.application;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class GettingBarChartValues implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		try
		{

			try {
				try {

					Thread.sleep(6000);
					
					webDriver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

					WebElement ele11 = webDriver.findElement(By.xpath("//div[@id='UtilizationChart']"));

					WebElement ele22 = ele11.findElement(By.cssSelector("g[class='highcharts-series highcharts-series-2 highcharts-tracker']"));

					List<WebElement> seriesZero =  ele22.findElements(By.tagName("rect"));

					System.out.println("series Zero charts (should be    12)..."+seriesZero.size());
					 
					int bar=0;
					//for each of the bar
					for (WebElement webElement : seriesZero) {
						
						System.out.println("Checking bar no.. "+bar++);
						String javaScript = "var evObj = document.createEvent('MouseEvents');" +
								"evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" +
								"arguments[0].dispatchEvent(evObj);";

						((JavascriptExecutor)webDriver).executeScript(javaScript,webElement);
						
						Thread.sleep(1500);
						
						printToolTipText(webDriver);
						
						
						Thread.sleep(1500);
					}
					

				} catch (Exception e) {

					System.out.println("Exception... "+e.getMessage());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				System.out.println("End");
			}

			System.out.println("End");
		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	 
	}

	public void printToolTipText(WebDriver webDriver)
	{
		try {
			List<WebElement> toolTips = webDriver.findElements(By.cssSelector("g[class='highcharts-tooltip']"));

			for (WebElement webElement : toolTips) {

				WebElement e1 = webElement.findElement(By.tagName("text"));

				List<WebElement> actualToolTipSPans  = e1.findElements(By.tagName("tspan"));

				if(actualToolTipSPans.size()==4)
				{
					for (WebElement webElement2 : actualToolTipSPans) {
						System.out.println(webElement2.getText());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			
			System.out.println("Not able to extract Tooltip text ");
		}
	}

}
