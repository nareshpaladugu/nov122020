package com.hdms.aetna.business.keywords.action;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.LoadProperties;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class WaitForReports implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		int maxRetries = 30;

		try
		{

			System.out.println("WaitForReportsToLoad... keyword started !");
			
			//waitForElementDisap(webDriver,By.xpath("//span[text()='Layout']"));

			webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			waitForElementDisap(webDriver,By.xpath("//span[text()='Apply']"));

			System.out.println("Apply Button gone !");

			webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

			// initial wait...
			waitForElementApp(webDriver,By.xpath("//div[contains(@class,'v-grid-tablewrapper')]"));
			


			Thread.sleep(5000);
			waitForElementApp(webDriver, By.xpath("//div[contains(@class,'v-grid-tablewrapper')]//thead"));


			int tablecount  = webDriver.findElements(By.xpath("//div[contains(@class,'v-grid-tablewrapper')]")).size();

			System.out.println("No of tables... "+tablecount);

			

			System.out.println("Done with report load check !!");

		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}
		finally
		{
			webDriver.manage().timeouts().implicitlyWait(Integer.parseInt(LoadProperties.OBJECT_LOAD_TIME), TimeUnit.SECONDS);
		}
		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}



	private void waitForElementApp(WebDriver webDriver,By by)
	{
		WebDriverWait wait = new WebDriverWait(webDriver, 30000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	private void waitForElementDisap(WebDriver webDriver,By by)
	{
		WebDriverWait wait = new WebDriverWait(webDriver, 30000);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}

}
