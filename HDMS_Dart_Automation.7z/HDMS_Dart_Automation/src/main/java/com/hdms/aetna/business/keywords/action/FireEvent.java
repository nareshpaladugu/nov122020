package com.hdms.aetna.business.keywords.action;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.locators.LocatorVO;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class FireEvent implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver,
			String... param) {
		TestStepExecutionResultVO result = new TestStepExecutionResultVO();

		String locator = param[0];

		//String eventName = param[1];
		
		LocatorVO locatorVO=new LocatorVO(locator);

		WebElement webElement=null;
		try {
			webElement = AutomationUtil.getElement(webDriver, locatorVO);

			System.out.println("fireevent .. ..... "+locator);

			String js="return triggerEvent(arguments[0],'blur');"
					+ ""
					+ "function triggerEvent(el, type){" + 
					"   if ('createEvent' in document) {" + 
					"       " + 
					"        var e = document.createEvent('HTMLEvents');" + 
					"        e.initEvent('click', true, true);" + 
					"        el.parentElement.parentElement.dispatchEvent(e);"
			
	/*				
		"        var e1 = document.createEvent('HTMLEvents');" + 
		"        e1.initEvent('blur', false, true);" + 
		"        el.parentElement.parentElement.dispatchEvent(e1);"
*/
		
					+ "		return 'ddone';" + 
					"    } else {" + 
					"        " + 
					"        var e = document.createEventObject();" + 
					"        e.eventType = type;" + 
					"        el.fireEvent('on'+e.eventType, e);" + 
					"    }" + 
					"}"
					+ ""
					+ "";
			
			//TODO - parameterize event later 

			System.out.println("output "+((JavascriptExecutor) webDriver).executeScript(js, webElement));


		} catch (Exception e) {

			result.setDefectDesc(e.getMessage());
			return result;
		}

		result.setStatus(Constants.PASS);
		return result;
	}

}
