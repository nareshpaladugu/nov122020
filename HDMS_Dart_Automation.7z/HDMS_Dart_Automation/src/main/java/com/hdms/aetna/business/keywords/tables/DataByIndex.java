package com.hdms.aetna.business.keywords.tables;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class DataByIndex implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();
		String value = params[1];
		try
		{

			WebElement table = AutomationUtil.getElement(webDriver, params[0]);

			WebElement header = table.findElement(By.tagName("thead"));

			WebElement headerRow = header.findElement(By.tagName("tr"));

			List<WebElement> allColInHeader = headerRow.findElements(By.tagName("th"));

			for (WebElement singleHeaderCell : allColInHeader) {

				System.out.print(singleHeaderCell.getText()+",");

			}

			System.out.println("\n");

			WebElement tbodyData = table.findElement(By.tagName("tbody"));

			List<WebElement> allActualDataRows = tbodyData.findElements(By.tagName("tr"));

			for (WebElement singleRowData : allActualDataRows) {

				List<WebElement> allCOlFromSingleRow = singleRowData.findElements(By.tagName("td"));
				
				allCOlFromSingleRow.get(2).click();
			}


		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}

		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}

}
