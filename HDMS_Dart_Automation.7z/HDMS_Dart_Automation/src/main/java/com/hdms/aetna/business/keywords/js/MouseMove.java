package com.hdms.aetna.business.keywords.js;

import java.awt.Robot;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class MouseMove implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();

		try
		{
			System.out.println("Doing mousemove... on "+params[0]);

			WebElement ele = AutomationUtil.getElement(webDriver, params[0]);

			Robot r = new Robot();

			System.out.println("ele.getLocation().getX(), ele.getLocation().getY() "+ele.getLocation().getX()+"&"+ ele.getLocation().getY());

			r.mouseMove(ele.getLocation().getX(), ele.getLocation().getY());

			//new Actions(webDriver).moveToElement(ele).click().build().perform();

		}
		catch (Exception e) {
			testStepExecutionResultVO.setDefectDesc("Exception "+e.getMessage());
			return testStepExecutionResultVO;
		}


		testStepExecutionResultVO.setStatus(Constants.PASS);

		return testStepExecutionResultVO;	
	}

}
