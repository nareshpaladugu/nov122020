package com.hdms.aetna.business.keywords.todo;

import java.util.Date;

import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSException;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

			try {
				System.out.println(new Date().getTime());
				System.out.println(AutomationUtil.getLastModifiedFile("C:\\Users\\ddaphal\\Downloads\\", new Date().getTime()));
			} catch (HDMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
