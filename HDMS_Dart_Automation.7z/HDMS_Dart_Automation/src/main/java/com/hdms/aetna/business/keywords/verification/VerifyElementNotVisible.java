package com.hdms.aetna.business.keywords.verification;

import org.openqa.selenium.WebDriver;

import com.hdms.aetna.business.KeywordInterface;
import com.hdms.aetna.business.util.Constants;
import com.hdms.aetna.utils.AutomationUtil;
import com.hdms.aetna.utils.HDMSException;
import com.hdms.aetna.vos.TestStepExecutionResultVO;

public class VerifyElementNotVisible implements KeywordInterface{

	@Override
	public TestStepExecutionResultVO execute(WebDriver webDriver, String... params) {

		TestStepExecutionResultVO testStepExecutionResultVO = new TestStepExecutionResultVO();


		if(params[0].isEmpty())
		{
			testStepExecutionResultVO.setDefectDesc("Object location not provided");
			return testStepExecutionResultVO;

		}
		else
		{
			try {
				AutomationUtil.getElement(webDriver, params[0]);
			} catch (HDMSException e) {
				testStepExecutionResultVO.setStatus(Constants.PASS);
				return testStepExecutionResultVO;

			}
		}


		

		testStepExecutionResultVO.setDefectDesc("Element Found");

		return testStepExecutionResultVO;	
	}

}
