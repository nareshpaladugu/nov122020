package com.hdms.tests;

import java.util.Date;

import com.hdms.aetna.business.util.HDMSWait;

public class MiscTest {


	public static void main(String[] s)
	{

		//System.out.println("..."+System.getProperty("user.name"));
		
		HDMSWait w = new HDMSWait();
		
		System.out.println(new Date());
		w.waitFor(4000l);
		
		System.out.println(new Date());
	}
}