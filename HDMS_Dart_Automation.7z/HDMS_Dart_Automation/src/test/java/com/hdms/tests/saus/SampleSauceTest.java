package com.hdms.tests.saus;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

public class SampleSauceTest {

	
	//https://:@ondemand.saucelabs.com:80/wd/hub

	public static final String USERNAME = "nareshpaladugu";
	public static final String ACCESS_KEY = "09e4abe0-0ac9-4957-a92d-1120b5314f7f";
	public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:443/wd/hub";

	public static void main(String[] args) throws Exception {

		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability("platform", Platform.WIN10);
		//caps.setCapability("version", "10");
		//caps.setVersion("10");
		
		WebDriver driver = new RemoteWebDriver(new URL(URL), caps);

		/**
		 * Goes to Sauce Lab's guinea-pig page and prints title
		 */

		driver.get("http://www.google.com");
		System.out.println("title of page is: " + driver.getTitle());

		driver.quit();
	}
}