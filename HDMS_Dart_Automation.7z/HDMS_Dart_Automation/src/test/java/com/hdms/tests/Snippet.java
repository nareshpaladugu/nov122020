package com.hdms.tests;

public class Snippet {
	public static final String USERNAME = "YOUR_USERNAME";
	  public static final String ACCESS_KEY = "YOUR_ACCESS_KEY";
	  public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:443/wd/hub";
	 
}

