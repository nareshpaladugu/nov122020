package com.hdms.tests;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SasDate2 {

	public static void main(String[] args) {
		String numdays1 = "19693";    
		Calendar cal = Calendar.getInstance();       
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.MONTH, Calendar.JANUARY);
		cal.set(Calendar.YEAR, 1960);
		cal.add(Calendar.DATE, Integer.parseInt(numdays1));

		    String strdate = null;

		    SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");

		    if (cal != null) {
		    strdate = sdf.format(cal.getTime());
		    }
		    System.out.println(strdate);
	
	}
}

