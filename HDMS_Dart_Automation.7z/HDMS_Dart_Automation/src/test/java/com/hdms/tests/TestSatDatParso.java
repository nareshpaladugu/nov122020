package com.hdms.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import com.epam.parso.Column;
import com.epam.parso.impl.SasFileReaderImpl;

public class TestSatDatParso {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub


		//InputStream streamIn = new FileInputStream(new File("Z:\\Users\\npaladug\\Desktop\\etg_elig_100.sas7bdat"));
		//InputStream streamIn = new FileInputStream(new File("Z:\\etl10000.sas7bdat"));
		InputStream streamIn = new FileInputStream(new File("C:\\Users\\npaladug\\Desktop\\dataart\\etg_elig_10k.sas7bdat"));

		com.epam.parso.SasFileReader sasFileReader = new SasFileReaderImpl(streamIn);


		List<String> colList = new LinkedList<String>();
		
		for (Column column : sasFileReader.getColumns()) {
			
			colList.add(column.getName());
			//System.out.println(column.getName());
		}
		
		System.out.println("col count : "+colList.size());
		
	/*	Object[][] allData  =		sasFileReader.readAll(); 
		
		for (int i = 0; i < allData.length; i++) {
			Object[] singleRow = allData[i];
			
			for (int j = 0; j < singleRow.length; j++) {
				System.out.print (allData[i][j]==null?"":allData[i][j].toString()+"    ");
			}
			
			System.out.println();
		}
		*/
		//
		//
		
		
		
		
		String lst="database_id,MEMBERID,MBRNO2,PATDOB,RELCODE,PLANRELATION,HIREDATE,HIREYEAR";
		
		
		//String lst="DATABASE_ID,MEMBERID,MBRNO2,PATDOB,RELCODE,PLANRELATION,HIREDATE,HIREYEAR";

		
		List<String> reqCols = Arrays.asList(lst.split(","));
		
		
		System.out.println(colList);
		List<Integer> reqColsIndex = new LinkedList<Integer>();
		
		for (String strColName : reqCols) {
			reqColsIndex.add(colList.indexOf(strColName));
		}
		
		System.out.println("Req col index... "+reqColsIndex);
		System.out.println("Req col index... "+reqCols);
		
		
		Long rowCount = sasFileReader.getSasFileProperties().getRowCount();
		
		for (int i = 0; i < rowCount.intValue(); i++) 
		{
			Object[] singleRow = sasFileReader.readNext();
			
			for (int j = 0; j <reqColsIndex.size(); j++) {
				System.out.print (singleRow[reqColsIndex.get(j)]==null?"":singleRow[reqColsIndex.get(j)].toString()+ "  |  ");
			}
			
			System.out.println();
		}
		
		
		streamIn.close();
	
	}
	

}
