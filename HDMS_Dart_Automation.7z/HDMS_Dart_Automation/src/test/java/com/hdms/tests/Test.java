package com.hdms.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.epam.parso.Column;
import com.epam.parso.impl.SasFileReaderImpl;

public class Test 
{
	public static Map<String,String> ColumnMapper;

	public static void main(String[] args) throws Exception{

		Set<String> uniqueKeyCOlumnValues = new HashSet<String>();

		InputStream streamIn = new FileInputStream(new File("Z:\\etg_elig_10k.sas7bdat"));

		com.epam.parso.SasFileReader sasFileReader = new SasFileReaderImpl(streamIn);

		List<String> colList = new LinkedList<String>();

		for (Column column : sasFileReader.getColumns()) {

			colList.add(column.getName().toLowerCase());
		}

		String lst="database_id,MEMBERID,MBRNO2,PAtDOB(date),PAtDOB,RELCODE,PLANRELATION,HIREDATE,HIREDATE(date),HIREYEAR";

		String keyColumns  ="DATABASE_ID,MEMBERID,PAtDOB,RELCODE,PLANRELATION,HIREdATE";

		List<String> reqCols = Arrays.asList(lst.toLowerCase().split(","));

		System.out.println(colList);

		List<Integer> reqColsIndex = new LinkedList<Integer>();

		for (String strColName : reqCols) {

			if(colList.indexOf(strColName.replaceAll("\\(date\\)", ""))!=-1)
				reqColsIndex.add(colList.indexOf(strColName.replaceAll("\\(date\\)", "")));
		}

	
		Long rowCount = sasFileReader.getSasFileProperties().getRowCount();

		System.out.println("col count : "+colList.size());

		System.out.println("row Count :"+rowCount);
	
		System.out.println("Req col index... "+reqColsIndex);

		System.out.println("Req col index... "+reqCols);

		Map<String,String> singleRowFromFile = new HashMap<String,String>();
		Map<String,String> singleRowFromFileOrg = new HashMap<String,String>();

		//key1= col name form file
		//val = column name from db
		ColumnMapper = new HashMap<String,String>();

		String singVal;

		String keyColsVal;

		String lastMd5="";
		Object[] singleRow ;

		for (int i = 0; i < rowCount.intValue(); i++) 
		{
			System.out.println("Processing row... "+i);
			singleRowFromFile = new HashMap<String,String>();
			singleRowFromFileOrg = new HashMap<String,String>();

			singleRow 	= sasFileReader.readNext();

			for (int j = 0; j < reqColsIndex.size(); j++) 
			{
				singVal=singleRow[reqColsIndex.get(j)]==null?"":singleRow[reqColsIndex.get(j)].toString();

				singleRowFromFileOrg.put(reqCols.get(j),singVal);
				if(reqCols.get(j).contains("(date)"))
					singVal=SasDate.getReadableDate(singVal);


				singleRowFromFile.put(reqCols.get(j),singVal);
			}


			keyColsVal = getRowValSingle(singleRowFromFileOrg, keyColumns, "");
			uniqueKeyCOlumnValues.add(keyColsVal);
			/*if(MD5.getMD5Hash(keyColsVal).equals(lastMd5))
			{
				//System.out.println("Duplicate record............");
			}
			else
			{
				System.out.println(getRowValSingle(singleRowFromFile, lst, " | "));
				System.out.println("\nkeyColsVal......."+keyColsVal+"  and MD5 ="+MD5.getMD5Hash(keyColsVal));
				System.out.println();
			}*/

			//lastMd5=MD5.getMD5Hash(keyColsVal);

			coreDataComp(singleRowFromFile, readFromDB(singleRowFromFile.get("col1")+singleRowFromFile.get("col2")));
		}


		System.out.println("Unique key column values count : "+uniqueKeyCOlumnValues.size());
		streamIn.close();

	}

	public static String getRowValSingle(Map<String,String> singleRowFromFile,String colNames,String delim)
	{
		String out =null;

		List<String> reqCols = Arrays.asList(colNames.toLowerCase().split(","));

		for (String string : reqCols) {

			if(out==null)
				out=singleRowFromFile.get(string);
			else
				out=out+delim+singleRowFromFile.get(string);
		}

		return out;
	}



	public static void coreDataComp(Map<String,String> singleRowFromFile,Map<String,String> mapOfRowFromDb)
	{

		String colNameFromFile;
		String colNameFromDb;

		String singleCellValFromFile;
		String singleCellValFromDb;


		Set<String> keSet  = ColumnMapper.keySet();

		for (String key : keSet) {

			colNameFromFile = key;
			colNameFromDb = ColumnMapper.get(key);

			singleCellValFromFile = singleRowFromFile.get(colNameFromFile);

			singleCellValFromDb = mapOfRowFromDb.get(colNameFromDb);

			System.out.println(singleCellValFromFile+"--"+singleCellValFromDb);

		}

	}


	public static Map<String,String> readFromDB(String primKey)
	{
		Map<String,String> mapOfRowFromDb = new HashMap<String, String>();

		//query db and create map

		mapOfRowFromDb.put("Col1InDb", "val1");

		return mapOfRowFromDb;
	}

}
